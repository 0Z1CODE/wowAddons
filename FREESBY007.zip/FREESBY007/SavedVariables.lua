
CHANNELPULLOUT_OPTIONS = {
	["displayActive"] = true,
	["name"] = "Список канала",
}

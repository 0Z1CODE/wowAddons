
RAID_PULLOUT_POSITIONS = {
}
RAID_SINGLE_POSITIONS = {
	{
		["y"] = 666.0741526940709,
		["x"] = 495.4073342989155,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Галяваншот",
	}, -- [1]
	{
		["y"] = -753.3333465548664,
		["x"] = -0,
		["point"] = "TOPLEFT",
		["relativePoint"] = "TOPLEFT",
		["settings"] = {
		},
		["name"] = "Lollabanny",
	}, -- [2]
}


FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Brisom - WoW Circle 3.3.5a x5"] = "Brisom - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Brisom - WoW Circle 3.3.5a x5"] = {
		},
	},
}


RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["Чудодемон"] = {
			["type"] = "Ungrouped",
			["Owner"] = false,
			["enClass"] = "DRUID",
			["unit"] = "Чудодемон",
			["Name"] = "Чудодемон",
			["LastAbility"] = 28254.197,
			["UnitLockout"] = 1656852208,
			["level"] = 80,
			["Fights"] = {
			},
			["LastFightIn"] = 0,
		},
		["Aqualid"] = {
			["type"] = "Ungrouped",
			["Owner"] = false,
			["enClass"] = "MAGE",
			["unit"] = "Aqualid",
			["Name"] = "Aqualid",
			["LastAbility"] = 28254.197,
			["UnitLockout"] = 1656851834,
			["level"] = 80,
			["Fights"] = {
			},
			["LastFightIn"] = 0,
		},
		["Pinichet"] = {
			["type"] = "Self",
			["Owner"] = false,
			["enClass"] = "MAGE",
			["Name"] = "Pinichet",
			["LastAbility"] = 28254.197,
			["UnitLockout"] = 1656851335,
			["level"] = 80,
			["Fights"] = {
			},
			["LastFightIn"] = 0,
		},
		["Supersuicide"] = {
			["type"] = "Ungrouped",
			["Owner"] = false,
			["enClass"] = "WARRIOR",
			["unit"] = "Supersuicide",
			["Name"] = "Supersuicide",
			["LastAbility"] = 28254.197,
			["UnitLockout"] = 1656851550,
			["level"] = 80,
			["Fights"] = {
			},
			["LastFightIn"] = 0,
		},
		["Друля"] = {
			["type"] = "Ungrouped",
			["Owner"] = false,
			["enClass"] = "DRUID",
			["unit"] = "Друля",
			["Name"] = "Друля",
			["LastAbility"] = 28254.197,
			["UnitLockout"] = 1656851553,
			["level"] = 80,
			["Fights"] = {
			},
			["LastFightIn"] = 0,
		},
	},
	["FightNum"] = 0,
	["CombatTimes"] = {
	},
	["FoughtWho"] = {
	},
}

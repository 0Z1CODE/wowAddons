
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Pinichet - WoW Circle 3.3.5a x5"] = "Pinichet - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Pinichet - WoW Circle 3.3.5a x5"] = {
		},
	},
}


RAID_PULLOUT_POSITIONS = {
}
RAID_SINGLE_POSITIONS = {
	{
		["y"] = 203.061772757273,
		["x"] = 508.8396473105931,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Jyn",
		["settings"] = {
		},
	}, -- [1]
	{
		["y"] = 277.3334923564609,
		["x"] = 513.5802288661033,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Raiderfire",
		["settings"] = {
		},
	}, -- [2]
	{
		["y"] = 304.1975756586837,
		["x"] = 457.7449737259645,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Борлант",
		["settings"] = {
		},
	}, -- [3]
	{
		["y"] = 182.5198479259279,
		["x"] = 843.5879408950973,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Юе",
	}, -- [4]
	{
		["y"] = 181.728560514945,
		["x"] = 734.0246592075793,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Ndracon",
	}, -- [5]
	{
		["y"] = 229.135846669244,
		["x"] = 540.9713294021157,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Курраж",
		["settings"] = {
		},
	}, -- [6]
	{
		["y"] = 263.9013894303828,
		["x"] = 511.9999649857334,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Лесяо",
		["settings"] = {
		},
	}, -- [7]
	{
		["y"] = 327.9013938071662,
		["x"] = 454.8476482072866,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Агентроо",
		["settings"] = {
		},
	}, -- [8]
	{
		["y"] = 338.1724087442386,
		["x"] = 285.4979614789725,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Dumtrakabeli",
		["settings"] = {
		},
	}, -- [9]
	{
		["y"] = 376.8885586849024,
		["x"] = 74.53479929131672,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Веллиминск",
		["settings"] = {
		},
	}, -- [10]
	{
		["y"] = 233.8768133816868,
		["x"] = 525.4318928404783,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Choisegtx",
		["settings"] = {
		},
	}, -- [11]
}

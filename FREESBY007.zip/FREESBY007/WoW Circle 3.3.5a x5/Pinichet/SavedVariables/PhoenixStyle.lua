
thisaddononoff = true
thisaddonwork = true
secrefmark = 1
pssetmarknew = {
	{
	}, -- [1]
	{
	}, -- [2]
	{
	}, -- [3]
	{
	}, -- [4]
	{
	}, -- [5]
	{
	}, -- [6]
	{
	}, -- [7]
	{
	}, -- [8]
}
psfnopromrep = false
PS_Settings = {
	["PSMinimapPos"] = -16,
}
psminibutenabl = true
psfchatadd = nil
psoldvern = 0
psversionday = 0
psaddoninstalledsins = "11/6/2021"


AtlasLootCharDB = {
	["QuickLooks"] = {
		[3] = {
			"TheStockade", -- [1]
			"", -- [2]
			"Тюрьма", -- [3]
			{
				"TOPLEFT", -- [1]
				"AtlasLootDefaultFrame_LootBackground", -- [2]
				"TOPLEFT", -- [3]
				"2", -- [4]
				"-2", -- [5]
			}, -- [4]
		},
	},
	["WishList"] = {
	},
	["AtlasLootVersion"] = "51104",
	["AutoQuery"] = false,
	["SearchResult"] = {
	},
}
AtlasLootFilterDB = {
	["Relics"] = {
		["Idol"] = true,
		["Libram"] = true,
		["Sigils"] = true,
		["Totem"] = true,
	},
	["WeaponsMeele"] = {
		["Axe"] = true,
		["Shield"] = true,
		["Held in Off-Hand"] = true,
		["Staff"] = true,
		["Dagger"] = true,
		["Mace"] = true,
		["Fist Weapon"] = true,
		["Polearm"] = true,
		["Sword"] = true,
	},
	["Armor"] = {
		["Leather"] = true,
		["Plate"] = true,
		["Cloth"] = true,
		["Mail"] = true,
	},
	["WeaponsMeeleTwoHand"] = {
		["Mace"] = true,
		["Sword"] = true,
		["Axe"] = true,
	},
	["Other"] = {
		["Neck"] = true,
		["Trinket"] = true,
		["Ring"] = true,
		["Back"] = true,
	},
	["WeaponsRanged"] = {
		["Crossbow"] = true,
		["Wand"] = true,
		["Gun"] = true,
		["Bow"] = true,
		["Thrown"] = true,
	},
}


FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Drmartin - WoW Circle 3.3.5a x5"] = "Drmartin - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Drmartin - WoW Circle 3.3.5a x5"] = {
		},
	},
}

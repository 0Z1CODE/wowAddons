
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Adamanum - WoW Circle 3.3.5a x5"] = "Adamanum - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Adamanum - WoW Circle 3.3.5a x5"] = {
		},
	},
}

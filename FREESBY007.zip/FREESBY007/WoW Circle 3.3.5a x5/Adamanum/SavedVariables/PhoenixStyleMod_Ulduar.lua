
whererepbossulda = {
	"raid", -- [1]
	"raid", -- [2]
	"raid", -- [3]
	"raid", -- [4]
	"raid", -- [5]
	"raid", -- [6]
	"raid", -- [7]
}
bosspartul = {
	1, -- [1]
	1, -- [2]
	1, -- [3]
	1, -- [4]
	1, -- [5]
	1, -- [6]
	1, -- [7]
}
bosspartul2 = {
	1, -- [1]
	1, -- [2]
	1, -- [3]
	1, -- [4]
	1, -- [5]
}
wherereportlevichat1 = "raid"
wherereportlevichat2 = "raid"
wherereportyogg = "raid"
yoggvar = nil
yoggvar2 = nil
primyogg = ""
yoggspisokp = {
}

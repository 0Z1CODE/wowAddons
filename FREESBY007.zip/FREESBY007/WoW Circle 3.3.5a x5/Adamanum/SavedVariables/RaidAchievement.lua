
thisaddonworkea = true
pseashowfailreas = true
pseashownewvervar = true
wherereportraidach = "raid"
wherereportpartyach = "party"
raquantrepeatach = 5
raquantrepeatachtm = 2
raoldvern = 0

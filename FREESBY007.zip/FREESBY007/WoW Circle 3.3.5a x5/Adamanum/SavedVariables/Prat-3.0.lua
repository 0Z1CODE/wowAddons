
Prat3PerCharDB = nil

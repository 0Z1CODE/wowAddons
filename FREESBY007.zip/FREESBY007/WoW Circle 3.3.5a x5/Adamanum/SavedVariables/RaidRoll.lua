
RR_Accept_All_Rolls = nil
RR_Track_Unannounced_Rolls = nil
RR_Roll_Tracking_Enabled = nil
RR_AllowExtraRolls = nil
RR_Show_Ranks = nil
RR_RankPriority = nil
RR_ExtraWidth = nil
RR_ShowGroupNumber = nil
RR_RollFrameHeight = nil

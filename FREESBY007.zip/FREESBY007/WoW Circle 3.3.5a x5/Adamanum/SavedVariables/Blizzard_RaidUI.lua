
RAID_PULLOUT_POSITIONS = {
}
RAID_SINGLE_POSITIONS = {
	{
		["y"] = -753.3333465548664,
		["x"] = -0,
		["point"] = "TOPLEFT",
		["relativePoint"] = "TOPLEFT",
		["name"] = "Темноокий",
		["settings"] = {
		},
	}, -- [1]
	{
		["y"] = 195.9513906237402,
		["x"] = 1221.793981389507,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Zedsham",
		["settings"] = {
		},
	}, -- [2]
	{
		["y"] = 188.83953789101,
		["x"] = 964.7407347429265,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Irorra",
	}, -- [3]
	{
		["y"] = 650.2715138903716,
		["x"] = 145.382657584203,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Глазнапопе",
		["settings"] = {
		},
	}, -- [4]
	{
		["y"] = 649.481872149919,
		["x"] = 320.7899262313687,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Озби",
		["settings"] = {
		},
	}, -- [5]
	{
		["y"] = 649.4817320928527,
		["x"] = 232.032541931123,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Kerrorr",
		["settings"] = {
		},
	}, -- [6]
	{
		["y"] = 336.5927050921344,
		["x"] = 556.2469684791588,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Phantomlight",
	}, -- [7]
	{
		["y"] = 404.543281634176,
		["x"] = 553.8767827442035,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Lsdherox",
	}, -- [8]
	{
		["y"] = 483.5556703245405,
		["x"] = 324.2139013340367,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Тани",
	}, -- [9]
	{
		["y"] = 572.0494672257917,
		["x"] = 540.9712243593159,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Irist",
		["settings"] = {
		},
	}, -- [10]
}

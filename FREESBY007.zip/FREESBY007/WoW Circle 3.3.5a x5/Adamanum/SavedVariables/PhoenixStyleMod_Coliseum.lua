
wherereporttwins = "raid"
twinspart = true
twinspart2 = false
twinspart3 = true
twinspart4 = false
zveripart = true
wherereportzveri = "raid"
pswelwidth = 150
pswelheight = 80
psgalochki = {
	"yes", -- [1]
	"yes", -- [2]
	"yes", -- [3]
}
wherereportinfshield = "raid"
wherereportjarax = "raid"
jaraxpart = true
jaraxpart2 = false
pscoltekver = 3
psanubheal = {
	"", -- [1]
	"", -- [2]
	"DBM-healerA", -- [3]
	"DBM-healerB", -- [4]
	"DBM-healerC", -- [5]
	"DBM-healerD", -- [6]
	"DBM-healerE", -- [7]
	"", -- [8]
}
wherereportanub = "raid"
wherereportanub2 = "raid"
psanubbop = {
	"BoP-A", -- [1]
	"BoP-B", -- [2]
	"BoP-C", -- [3]
	"BoP-D", -- [4]
}

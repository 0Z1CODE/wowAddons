
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Palamalka - WoW Circle 3.3.5a x5"] = "Palamalka - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Palamalka - WoW Circle 3.3.5a x5"] = {
		},
	},
}

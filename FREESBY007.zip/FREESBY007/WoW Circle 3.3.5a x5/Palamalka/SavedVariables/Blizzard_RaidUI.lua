
RAID_PULLOUT_POSITIONS = {
}
RAID_SINGLE_POSITIONS = {
	{
		["y"] = 545.1852963879023,
		["x"] = 146.9629652324062,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Shandan",
		["settings"] = {
		},
	}, -- [1]
	{
		["y"] = 467.7532065921743,
		["x"] = 621.5638769300504,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Штейдер",
		["settings"] = {
		},
	}, -- [2]
	{
		["y"] = 190.4201168997794,
		["x"] = 981.5963926004733,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Destiiny",
		["settings"] = {
		},
	}, -- [3]
}


BaudBag_Cfg = {
	{
		{
			["AutoOpen"] = false,
			["RarityColor"] = true,
			["Columns"] = 8,
			["Coords"] = {
				1129.086217502469, -- [1]
				353.9753276620708, -- [2]
			},
			["Scale"] = 100,
			["Background"] = 1,
			["BlankTop"] = false,
			["Name"] = "Drugano's Inventory",
		}, -- [1]
		{
			["AutoOpen"] = false,
			["RarityColor"] = true,
			["Columns"] = 4,
			["Coords"] = {
				758.5185392677136, -- [1]
				426.6666608309556, -- [2]
			},
			["Scale"] = 100,
			["Background"] = 3,
			["BlankTop"] = false,
			["Name"] = "Key Ring",
		}, -- [2]
		["Enabled"] = true,
		["Joined"] = {
			[6] = false,
		},
		["ShowBags"] = false,
	}, -- [1]
	{
		{
			["AutoOpen"] = false,
			["RarityColor"] = true,
			["Columns"] = 12,
			["Coords"] = {
				758.5185392677136, -- [1]
				426.6666608309556, -- [2]
			},
			["Scale"] = 100,
			["Background"] = 1,
			["BlankTop"] = false,
			["Name"] = "Drugano's Bank Box",
		}, -- [1]
		["Enabled"] = true,
		["Joined"] = {
		},
		["ShowBags"] = true,
	}, -- [2]
}
BaudBag_Cache = {
	[5] = {
		["Size"] = 0,
	},
	[6] = {
		["Size"] = 0,
	},
	[7] = {
		["Size"] = 0,
	},
	[9] = {
		["Size"] = 0,
	},
	[11] = {
		["Size"] = 0,
	},
	[10] = {
		["Size"] = 0,
	},
	[8] = {
		["Size"] = 0,
	},
	[-1] = {
		["Size"] = 28,
	},
}

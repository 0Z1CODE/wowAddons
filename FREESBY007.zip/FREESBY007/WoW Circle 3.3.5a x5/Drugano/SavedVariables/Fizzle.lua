
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = "Drugano - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = {
		},
	},
}

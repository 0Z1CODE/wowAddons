
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Adolifa - WoW Circle 3.3.5a x5"] = {
		},
	},
}

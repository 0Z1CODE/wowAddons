
preaspisokon = {
	"yes", -- [1]
	"yes", -- [2]
	"yes", -- [3]
	"yes", -- [4]
	"yes", -- [5]
	"yes", -- [6]
	"yes", -- [7]
	"yes", -- [8]
	"yes", -- [9]
	"yes", -- [10]
	"yes", -- [11]
	"yes", -- [12]
	"yes", -- [13]
	"yes", -- [14]
	"yes", -- [15]
}

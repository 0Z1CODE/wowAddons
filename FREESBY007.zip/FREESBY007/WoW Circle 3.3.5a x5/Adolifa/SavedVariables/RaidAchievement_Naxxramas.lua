
nxraspisokon = {
	"yes", -- [1]
	"yes", -- [2]
	"yes", -- [3]
	"yes", -- [4]
	"yes", -- [5]
	"yes", -- [6]
	"yes", -- [7]
}

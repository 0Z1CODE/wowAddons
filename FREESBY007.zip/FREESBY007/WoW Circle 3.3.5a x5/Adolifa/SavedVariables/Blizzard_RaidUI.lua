
RAID_PULLOUT_POSITIONS = {
}
RAID_SINGLE_POSITIONS = {
	{
		["y"] = 223.6050631450156,
		["x"] = 1017.67894447852,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Melioreqt",
		["settings"] = {
		},
	}, -- [1]
	{
		["y"] = 141.4321992153111,
		["x"] = 888.0990570015164,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Камилочка",
		["settings"] = {
		},
	}, -- [2]
	{
		["y"] = 286.8147955245476,
		["x"] = 613.1358029014107,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Geew",
		["settings"] = {
		},
	}, -- [3]
	{
		["y"] = 201.4814738626364,
		["x"] = 1084.312774510653,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Мистрлихо",
		["settings"] = {
		},
	}, -- [4]
	{
		["y"] = 174.6170754320142,
		["x"] = 413.2343128050114,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Подбухни",
		["settings"] = {
		},
	}, -- [5]
	{
		["y"] = 151.7038619163158,
		["x"] = 927.0786192698417,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Lustlove",
	}, -- [6]
	{
		["y"] = 362.6667790041054,
		["x"] = 551.7694841229107,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Sigmaier",
	}, -- [7]
	{
		["y"] = 176.9877688738352,
		["x"] = 396.6417171324601,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Niggaspwnz",
	}, -- [8]
	{
		["y"] = 168.2964225746004,
		["x"] = 456.6911843582518,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Nemmochka",
	}, -- [9]
	{
		["y"] = 186.4691770847217,
		["x"] = 1039.802288661033,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Штейдер",
	}, -- [10]
	{
		["y"] = -753.3333465548664,
		["x"] = 994.8560852777935,
		["point"] = "TOPLEFT",
		["relativePoint"] = "TOPLEFT",
		["settings"] = {
		},
		["name"] = "Этомойхолик",
	}, -- [11]
	{
		["y"] = 386.3704570955214,
		["x"] = 539.9176100629361,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Tolagg",
		["settings"] = {
		},
	}, -- [12]
	{
		["y"] = 396.641997246593,
		["x"] = 455.1111655777481,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Соршами",
	}, -- [13]
	{
		["y"] = 445.6295122669953,
		["x"] = 456.6914644723846,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Рыцарьсмерти",
	}, -- [14]
}

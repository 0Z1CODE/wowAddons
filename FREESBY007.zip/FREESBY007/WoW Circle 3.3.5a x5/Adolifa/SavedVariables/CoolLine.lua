
CoolLineCharDB = nil

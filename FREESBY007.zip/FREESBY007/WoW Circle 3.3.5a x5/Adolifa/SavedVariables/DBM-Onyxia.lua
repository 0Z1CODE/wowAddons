
DBMOnyxia_SavedVars = {
	["Onyxia"] = {
		["Timer17086Onyxia2"] = true,
		["WarnPhase3Soon"] = true,
		["HealthFrame"] = false,
		["Вспышка огненной звезды - бегите"] = false,
		["Timer17086Onyxia1"] = true,
		["Timer4406Onyxia5"] = true,
		["Фаза 2"] = true,
		["Дыхание - бегите"] = true,
		["Enabled"] = true,
		["Announce"] = false,
		["Timer68970Onyxia0"] = true,
		["Звуковой сигнал при $spell:17086"] = true,
		["Фаза 3"] = true,
		["WarnWhelpsSoon"] = true,
		["TimerWhelps"] = true,
		["Timer4405Onyxia4"] = true,
		["Звуковой сигнал при $spell:68958"] = false,
		["WarnPhase2Soon"] = true,
		["SoundWTF"] = false,
	},
}
DBMOnyxia_SavedStats = {
	["Onyxia"] = {
		["heroicBestTime"] = 128.0569999999998,
		["kills"] = 1,
		["heroicKills"] = 1,
		["heroicLastTime"] = 128.0569999999998,
		["pulls"] = 1,
		["lastTime"] = 144.7070000000003,
		["bestTime"] = 144.7070000000003,
		["heroicPulls"] = 1,
	},
}

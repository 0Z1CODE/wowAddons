
RAID_PULLOUT_POSITIONS = {
}
RAID_SINGLE_POSITIONS = {
	{
		["y"] = 301.8273198951952,
		["x"] = 621.0369822461939,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Вредныйдк",
	}, -- [1]
	{
		["y"] = 573.629696091895,
		["x"] = 464.329161460973,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Кеексиик",
		["settings"] = {
		},
	}, -- [2]
	{
		["y"] = 473.2840251306692,
		["x"] = 414.5515145003857,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Тётьдаша",
	}, -- [3]
	{
		["y"] = 576.0002319695162,
		["x"] = 1180.971268127149,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Manxx",
		["settings"] = {
		},
	}, -- [4]
	{
		["y"] = 351.6058422124476,
		["x"] = 303.6708910604269,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Bafoode",
	}, -- [5]
	{
		["y"] = 350.8147298727977,
		["x"] = 427.4569678424736,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Asmatika",
	}, -- [6]
	{
		["y"] = 340.5431547074596,
		["x"] = 416.9215951925412,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Декаффка",
		["settings"] = {
		},
	}, -- [7]
	{
		["y"] = 385.5804652124029,
		["x"] = 417.448454862131,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Bilorka",
	}, -- [8]
	{
		["y"] = 534.9135811654977,
		["x"] = 288.131594555856,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Гестапов",
		["settings"] = {
		},
	}, -- [9]
	{
		["y"] = 463.0124149510645,
		["x"] = 491.4568146550571,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Йафет",
	}, -- [10]
	{
		["y"] = 472.4941032760839,
		["x"] = 394.0082591269097,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Anerkot",
		["settings"] = {
		},
	}, -- [11]
	{
		["y"] = 588.6422729839425,
		["x"] = 213.8600500280012,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Bandef",
		["settings"] = {
		},
	}, -- [12]
	{
		["y"] = 614.7160667817807,
		["x"] = 357.9257772773959,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Narika",
	}, -- [13]
	{
		["y"] = 361.8766470639204,
		["x"] = 452.4774274580648,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Anlova",
	}, -- [14]
	{
		["y"] = 491.4569897263902,
		["x"] = 491.7201919684521,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Мецинат",
		["settings"] = {
		},
	}, -- [15]
	{
		["y"] = 460.6420891590428,
		["x"] = 373.7284510953618,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Glauccoma",
	}, -- [16]
	{
		["y"] = 470.1234973699293,
		["x"] = 392.4279952465398,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Bloodstrik",
		["settings"] = {
		},
	}, -- [17]
	{
		["y"] = 373.7286261666949,
		["x"] = 400.8561743179792,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Квакиутль",
		["settings"] = {
		},
	}, -- [18]
	{
		["y"] = 433.7782684638195,
		["x"] = 400.5924468619182,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Медузонька",
		["settings"] = {
		},
	}, -- [19]
	{
		["y"] = 400.592551904718,
		["x"] = 397.9588487993013,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["settings"] = {
		},
		["name"] = "Unionwind",
	}, -- [20]
}


FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Saylee - WoW Circle 3.3.5a x5"] = "Saylee - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Saylee - WoW Circle 3.3.5a x5"] = {
		},
	},
}


FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Freeby - WoW Circle 3.3.5a x5"] = "Freeby - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Freeby - WoW Circle 3.3.5a x5"] = {
		},
	},
}


RAID_PULLOUT_POSITIONS = {
}
RAID_SINGLE_POSITIONS = {
	{
		["y"] = 368.1979826995329,
		["x"] = 343.1771729412757,
		["point"] = "TOP",
		["relativePoint"] = "BOTTOMLEFT",
		["name"] = "Proxqq",
		["settings"] = {
		},
	}, -- [1]
	{
		["y"] = -753.3333465548664,
		["x"] = 1018.296035913148,
		["point"] = "TOPLEFT",
		["relativePoint"] = "TOPLEFT",
		["settings"] = {
		},
		["name"] = "Правдивая",
	}, -- [2]
}


DBM_UsedProfile = "Default"
DBM_UseDualProfile = false
DBM_CharSavedRevision = nil
DBM_SavedOptions = {
	["SpecialWarningFontSize"] = 50,
	["ShowWarningsInChat"] = true,
	["DontSetIcons"] = false,
	["BigBrotherAnnounceToRaid"] = false,
	["ArrowPosX"] = 0,
	["HPFramePoint"] = "CENTER",
	["AutoRespond"] = true,
	["HealthFrameGrowUp"] = false,
	["StatusEnabled"] = true,
	["HideBossEmoteFrame"] = false,
	["ShowBigBrotherOnCombatStart"] = false,
	["BlockVersionUpdatePopup"] = true,
	["WarningColors"] = {
		{
			["r"] = 0.41,
			["g"] = 0.8,
			["b"] = 0.94,
		}, -- [1]
		{
			["r"] = 0.95,
			["g"] = 0.95,
			["b"] = 0,
		}, -- [2]
		{
			["r"] = 1,
			["g"] = 0.5,
			["b"] = 0,
		}, -- [3]
		{
			["r"] = 1,
			["g"] = 0.1,
			["b"] = 0.1,
		}, -- [4]
	},
	["RangeFrameY"] = -50,
	["SpecialWarningFont"] = "Fonts\\FRIZQT__.TTF",
	["SpamBlockRaidWarning"] = true,
	["ShowFakedRaidWarnings"] = false,
	["LatencyThreshold"] = 250,
	["DontSendBossAnnounces"] = false,
	["HPFrameMaxEntries"] = 5,
	["ArrowPoint"] = "TOP",
	["RangeFramePoint"] = "CENTER",
	["SpecialWarningPoint"] = "CENTER",
	["ArrowPosY"] = -150,
	["RaidWarningSound"] = "Sound\\Doodad\\BellTollNightElf.wav",
	["SpecialWarningSound"] = "Sound\\Spells\\PVPFlagTaken.wav",
	["HealthFrameLocked"] = false,
	["SpecialWarningY"] = 75,
	["RangeFrameSound2"] = "none",
	["ShowMinimapButton"] = true,
	["RaidWarningPosition"] = {
		["Y"] = -185,
		["X"] = 0,
		["Point"] = "TOP",
	},
	["SpecialWarningX"] = 0,
	["Enabled"] = true,
	["SpecialWarningFontColor"] = {
		0, -- [1]
		0, -- [2]
		1, -- [3]
	},
	["DontSendBossWhispers"] = false,
	["HealthFrameWidth"] = 200,
	["RangeFrameLocked"] = false,
	["WarningIconLeft"] = true,
	["RangeFrameSound1"] = "none",
	["HPFrameY"] = 50.00000068387239,
	["FixCLEUOnCombatStart"] = false,
	["RangeFrameX"] = 50,
	["AlwaysShowHealthFrame"] = false,
	["HPFrameX"] = -50.00000068387239,
	["DontShowBossAnnounces"] = false,
	["SpamBlockBossWhispers"] = false,
	["ShowSpecialWarnings"] = true,
	["WarningIconRight"] = true,
}

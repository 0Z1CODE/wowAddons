
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Godlite - WoW Circle 3.3.5a x5"] = "Godlite - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Godlite - WoW Circle 3.3.5a x5"] = {
		},
	},
}

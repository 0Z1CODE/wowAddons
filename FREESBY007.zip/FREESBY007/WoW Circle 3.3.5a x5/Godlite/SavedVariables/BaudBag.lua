
BaudBag_Cfg = {
	{
		{
			["AutoOpen"] = false,
			["Coords"] = {
				1152.789564502625, -- [1]
				410.0744425500294, -- [2]
			},
			["Columns"] = 9,
			["RarityColor"] = true,
			["Scale"] = 64,
			["Background"] = 1,
			["BlankTop"] = false,
			["Name"] = "Godlite's Inventory",
		}, -- [1]
		{
			["AutoOpen"] = false,
			["Coords"] = {
				758.5185392677136, -- [1]
				426.6666608309556, -- [2]
			},
			["Columns"] = 4,
			["RarityColor"] = true,
			["Scale"] = 100,
			["Background"] = 3,
			["BlankTop"] = false,
			["Name"] = "Key Ring",
		}, -- [2]
		["Enabled"] = true,
		["Joined"] = {
			[6] = false,
		},
		["ShowBags"] = false,
	}, -- [1]
	{
		{
			["AutoOpen"] = false,
			["Coords"] = {
				758.5185392677136, -- [1]
				426.6666608309556, -- [2]
			},
			["Columns"] = 12,
			["RarityColor"] = true,
			["Scale"] = 100,
			["Background"] = 1,
			["BlankTop"] = false,
			["Name"] = "Godlite's Bank Box",
		}, -- [1]
		["Enabled"] = true,
		["Joined"] = {
		},
		["ShowBags"] = true,
	}, -- [2]
}
BaudBag_Cache = {
	[5] = {
		["Size"] = 0,
	},
	[6] = {
		["Size"] = 0,
	},
	[7] = {
		["Size"] = 0,
	},
	[9] = {
		["Size"] = 0,
	},
	[11] = {
		["Size"] = 0,
	},
	[10] = {
		["Size"] = 0,
	},
	[8] = {
		["Size"] = 0,
	},
	[-1] = {
		["Size"] = 28,
	},
}

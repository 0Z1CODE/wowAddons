
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["Godlite"] = {
			["GUID"] = "0x000000000083035D",
			["LastEventHealth"] = {
				"63 (100%)", -- [1]
			},
			["LastAttackedBy"] = "Чащобный тенетник",
			["LastEventType"] = {
				"DAMAGE", -- [1]
			},
			["TimeWindows"] = {
				["DamageTaken"] = {
					7, -- [1]
				},
			},
			["enClass"] = "DRUID",
			["unit"] = "Godlite",
			["level"] = 1,
			["LastDamageAbility"] = "Атака ближнего боя",
			["LastFightIn"] = 0,
			["LastEventNum"] = {
				11.11111111111111, -- [1]
			},
			["type"] = "Self",
			["FightsSaved"] = 1,
			["LastDamageTaken"] = 7,
			["Owner"] = false,
			["TimeLast"] = {
				["DamageTaken"] = 1657918078,
				["OVERALL"] = 1657918078,
			},
			["NextEventNum"] = 2,
			["LastEventHealthNum"] = {
				100, -- [1]
			},
			["LastEvents"] = {
				"Чащобный тенетник Атака ближнего боя Godlite Crushing -7 (Physical)", -- [1]
			},
			["Name"] = "Godlite",
			["LastEventIncoming"] = {
				true, -- [1]
			},
			["LastEventTimes"] = {
				28934.763, -- [1]
			},
			["Fights"] = {
				["Fight1"] = {
					["PartialResist"] = {
						["Атака ближнего боя"] = {
							["Details"] = {
								["Нет сопротивлений"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Атака ближнего боя"] = {
							["Details"] = {
								["Нет поглощений"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Чащобный тенетник"] = {
							["Details"] = {
								["Атака ближнего боя"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 7,
					},
					["DamageTaken"] = 7,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Crushing"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
				["LastFightData"] = {
					["PartialResist"] = {
						["Атака ближнего боя"] = {
							["Details"] = {
								["Нет сопротивлений"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Атака ближнего боя"] = {
							["Details"] = {
								["Нет поглощений"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Чащобный тенетник"] = {
							["Details"] = {
								["Атака ближнего боя"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 7,
					},
					["DamageTaken"] = 7,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Crushing"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["PartialResist"] = {
						["Атака ближнего боя"] = {
							["Details"] = {
								["Нет сопротивлений"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Атака ближнего боя"] = {
							["Details"] = {
								["Нет поглощений"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Чащобный тенетник"] = {
							["Details"] = {
								["Атака ближнего боя"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 7,
					},
					["DamageTaken"] = 7,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Crushing"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
			},
			["UnitLockout"] = 1657918078,
			["LastActive"] = 1657918078,
		},
	},
	["FightNum"] = 1,
	["CombatTimes"] = {
		{
			1657918078, -- [1]
			1657918088, -- [2]
			"23:47:59", -- [3]
			"23:48:08", -- [4]
			"Чащобный тенетник", -- [5]
		}, -- [1]
	},
	["FoughtWho"] = {
		"Чащобный тенетник 23:47:59-23:48:08", -- [1]
	},
}

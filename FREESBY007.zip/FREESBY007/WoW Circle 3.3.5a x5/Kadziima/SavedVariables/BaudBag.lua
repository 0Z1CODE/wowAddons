
BaudBag_Cfg = {
	{
		{
			["AutoOpen"] = false,
			["Name"] = "Kadziima's Inventory",
			["Columns"] = 8,
			["BlankTop"] = false,
			["RarityColor"] = true,
			["Coords"] = {
				1193.086624543319, -- [1]
				413.2344528620778, -- [2]
			},
			["Background"] = 1,
			["Scale"] = 100,
		}, -- [1]
		{
			["AutoOpen"] = false,
			["Name"] = "Key Ring",
			["Columns"] = 4,
			["BlankTop"] = false,
			["RarityColor"] = true,
			["Coords"] = {
				758.5185392677136, -- [1]
				426.6666608309556, -- [2]
			},
			["Background"] = 3,
			["Scale"] = 100,
		}, -- [2]
		["Enabled"] = true,
		["Joined"] = {
			[6] = false,
		},
		["ShowBags"] = false,
	}, -- [1]
	{
		{
			["AutoOpen"] = false,
			["Name"] = "Kadziima's Bank Box",
			["Columns"] = 12,
			["BlankTop"] = false,
			["RarityColor"] = true,
			["Coords"] = {
				758.5185392677136, -- [1]
				426.6666608309556, -- [2]
			},
			["Background"] = 1,
			["Scale"] = 100,
		}, -- [1]
		["Enabled"] = true,
		["Joined"] = {
		},
		["ShowBags"] = true,
	}, -- [2]
}
BaudBag_Cache = {
	[5] = {
		["Size"] = 0,
	},
	[6] = {
		["Size"] = 0,
	},
	[7] = {
		["Size"] = 0,
	},
	[9] = {
		["Size"] = 0,
	},
	[11] = {
		["Size"] = 0,
	},
	[-1] = {
		["Size"] = 28,
	},
	[8] = {
		["Size"] = 0,
	},
	[10] = {
		["Size"] = 0,
	},
}


Omen3DB = {
	["profileKeys"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = "Drugano - WoW Circle 3.3.5a x5",
		["Saylee - WoW Circle 3.3.5a x5"] = "Saylee - WoW Circle 3.3.5a x5",
		["Godlite - WoW Circle 3.3.5a x5"] = "Godlite - WoW Circle 3.3.5a x5",
		["Freeby - WoW Circle 3.3.5a x5"] = "Freeby - WoW Circle 3.3.5a x5",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Palamalka - WoW Circle 3.3.5a x5",
		["Kadziima - WoW Circle 3.3.5a x5"] = "Kadziima - WoW Circle 3.3.5a x5",
		["Brisom - WoW Circle 3.3.5a x5"] = "Brisom - WoW Circle 3.3.5a x5",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa - WoW Circle 3.3.5a x5",
		["Adamanum - WoW Circle 3.3.5a x5"] = "Adamanum - WoW Circle 3.3.5a x5",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Pinichet - WoW Circle 3.3.5a x5",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Drmartin - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = {
			["PositionX"] = 1316.043423435117,
			["PositionY"] = 502.4568266228241,
			["PositionW"] = 200.0000027354896,
			["PositionH"] = 81.99999849548074,
		},
		["Saylee - WoW Circle 3.3.5a x5"] = {
			["PositionW"] = 228.4444024394823,
			["PositionH"] = 109.6543713020883,
			["VGrip2"] = 131.3554836129353,
			["PositionY"] = 365.7661718553547,
			["VGrip1"] = 97.08883571390869,
			["PositionX"] = 1288.592658588811,
		},
		["Godlite - WoW Circle 3.3.5a x5"] = {
			["PositionX"] = 646.0185410115881,
			["PositionY"] = 501.6666946826391,
		},
		["Freeby - WoW Circle 3.3.5a x5"] = {
			["PositionX"] = 1306.765623184533,
			["PositionY"] = 495.345674175426,
			["PositionW"] = 199.9999502140897,
			["PositionH"] = 81.99999849548074,
		},
		["Palamalka - WoW Circle 3.3.5a x5"] = {
			["PositionX"] = 1317.037128321337,
			["PositionY"] = 332.5802101963869,
			["PositionW"] = 199.9999502140897,
			["PositionH"] = 81.99999849548074,
		},
		["Kadziima - WoW Circle 3.3.5a x5"] = {
			["PositionW"] = 200.0000027354896,
			["PositionY"] = 183.2470242147589,
			["PositionX"] = 1112.191343666326,
			["PositionH"] = 81.99999849548074,
		},
		["Brisom - WoW Circle 3.3.5a x5"] = {
			["PositionW"] = 199.9999502140897,
			["PositionY"] = 483.4937300869181,
			["PositionX"] = 1316.246646238486,
			["PositionH"] = 81.99999849548074,
		},
		["Adolifa - WoW Circle 3.3.5a x5"] = {
			["VGrip2"] = 136.3530260499921,
			["PositionY"] = 399.7414601263755,
			["PositionW"] = 237.135801260117,
			["Warnings"] = {
				["Message"] = true,
				["SinkOptions"] = {
					["sink20OutputSink"] = "MikSBT",
				},
				["Shake"] = true,
			},
			["ShowWith"] = {
				["Party"] = false,
				["Pet"] = false,
				["Raid"] = false,
			},
			["PositionH"] = 119.9258939460265,
			["PositionX"] = 1154.272259584831,
			["VGrip1"] = 100.7826714282551,
		},
		["Adamanum - WoW Circle 3.3.5a x5"] = {
			["VGrip2"] = 132.7185420370885,
			["PositionY"] = 443.8778185373324,
			["PositionW"] = 230.8147807529038,
			["Warnings"] = {
				["Message"] = true,
				["SinkOptions"] = {
					["sink20OutputSink"] = "Всплывающий",
				},
			},
			["PositionX"] = 1284.641508688154,
			["VGrip1"] = 98.09631367958717,
			["PositionH"] = 87.53086955537557,
		},
		["Pinichet - WoW Circle 3.3.5a x5"] = {
			["PositionW"] = 199.9999502140897,
			["PositionY"] = 434.5064601663821,
			["PositionX"] = 1317.036848207205,
			["PositionH"] = 81.99999849548074,
		},
		["Drmartin - WoW Circle 3.3.5a x5"] = {
			["PositionX"] = 1317.037128321337,
			["PositionY"] = 297.8151051135806,
			["PositionW"] = 200.0000027354896,
			["PositionH"] = 81.99999849548074,
		},
	},
}

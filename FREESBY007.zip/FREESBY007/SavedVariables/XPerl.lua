
XPerlConfig = nil
XPerlConfig_Global = nil
XPerlConfigNew = {
	["global"] = {
		["showReadyCheck"] = 1,
		["highlight"] = {
			["enable"] = 1,
			["AGGRO"] = 1,
		},
		["highlightSelection"] = 1,
		["optionsColour"] = {
			["r"] = 0.7,
			["g"] = 0.2,
			["b"] = 0.2,
		},
		["rangeFinder"] = {
			["StatsFrame"] = {
				["FadeAmount"] = 0.5,
				["HealthLowPoint"] = 0.85,
				["item"] = "Heavy Netherweave Bandage",
			},
			["Main"] = {
				["enabled"] = true,
				["item"] = "Heavy Netherweave Bandage",
				["FadeAmount"] = 0.5,
				["HealthLowPoint"] = 0.85,
			},
			["NameFrame"] = {
				["FadeAmount"] = 0.5,
				["HealthLowPoint"] = 0.85,
				["item"] = "Heavy Netherweave Bandage",
			},
		},
		["showAFK"] = 1,
		["ShowTutorials"] = true,
		["buffHelper"] = {
			["enable"] = 1,
			["sort"] = "group",
			["visible"] = 1,
		},
		["focus"] = {
			["debuffs"] = {
				["enable"] = 1,
				["size"] = 26,
				["curable"] = 0,
				["big"] = 1,
			},
			["portrait"] = 1,
			["combo"] = {
				["enable"] = 1,
				["blizzard"] = 1,
				["pos"] = "top",
			},
			["enable"] = 1,
			["mana"] = 1,
			["castBar"] = {
				["enable"] = 1,
			},
			["hitIndicator"] = 1,
			["level"] = 1,
			["sound"] = 1,
			["size"] = {
				["width"] = 0,
			},
			["threat"] = 1,
			["portrait3D"] = 1,
			["healerMode"] = {
				["type"] = 0,
			},
			["mobType"] = 1,
			["highlightDebuffs"] = {
				["who"] = 1,
			},
			["raidIconAlternate"] = 1,
			["ownDamageOnly"] = 1,
			["threatMode"] = "portraitFrame",
			["elite"] = true,
			["scale"] = 0.78,
			["values"] = 1,
			["buffs"] = {
				["big"] = 1,
				["size"] = 19,
				["above"] = 1,
				["castable"] = 1,
				["enable"] = 1,
				["rows"] = 5,
				["wrap"] = 1,
				["maxrows"] = 2,
			},
			["percent"] = 1,
			["classIcon"] = 1,
		},
		["target"] = {
			["debuffs"] = {
				["enable"] = 1,
				["size"] = 29,
				["curable"] = 0,
				["big"] = 1,
			},
			["portrait"] = 1,
			["combo"] = {
				["enable"] = 1,
				["blizzard"] = 1,
				["pos"] = "top",
			},
			["enable"] = 1,
			["mana"] = 1,
			["castBar"] = {
				["enable"] = 1,
			},
			["hitIndicator"] = 1,
			["defer"] = 1,
			["level"] = 1,
			["sound"] = 1,
			["size"] = {
				["width"] = 0,
			},
			["ownDamageOnly"] = 1,
			["threat"] = 1,
			["portrait3D"] = 1,
			["pvpIcon"] = 1,
			["reactionHighlight"] = 1,
			["mobType"] = 1,
			["highlightDebuffs"] = {
				["who"] = 2,
			},
			["raidIconAlternate"] = 1,
			["healerMode"] = {
				["type"] = 1,
			},
			["threatMode"] = "portraitFrame",
			["scale"] = 0.83,
			["values"] = 1,
			["elite"] = 1,
			["buffs"] = {
				["size"] = 22,
				["castable"] = 0,
				["enable"] = 1,
				["wrap"] = 1,
				["rows"] = 3,
				["maxrows"] = 2,
			},
			["percent"] = 1,
			["classIcon"] = 1,
		},
		["raid"] = {
			["debuffs"] = {
				["enable"] = 1,
				["size"] = 20,
			},
			["enable"] = 1,
			["class"] = {
				{
					["enable"] = 1,
					["name"] = "WARRIOR",
				}, -- [1]
				{
					["enable"] = 1,
					["name"] = "ROGUE",
				}, -- [2]
				{
					["enable"] = 1,
					["name"] = "HUNTER",
				}, -- [3]
				{
					["enable"] = 1,
					["name"] = "MAGE",
				}, -- [4]
				{
					["enable"] = 1,
					["name"] = "WARLOCK",
				}, -- [5]
				{
					["enable"] = 1,
					["name"] = "PRIEST",
				}, -- [6]
				{
					["enable"] = 1,
					["name"] = "DRUID",
				}, -- [7]
				{
					["enable"] = 1,
					["name"] = "SHAMAN",
				}, -- [8]
				{
					["enable"] = 1,
					["name"] = "PALADIN",
				}, -- [9]
				{
					["enable"] = 1,
					["name"] = "DEATHKNIGHT",
				}, -- [10]
			},
			["group"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
				1, -- [6]
				1, -- [7]
				1, -- [8]
				1, -- [9]
			},
			["titles"] = 1,
			["scale"] = 0.8,
			["healerMode"] = {
				["type"] = 1,
			},
			["spacing"] = 0,
			["anchor"] = "TOP",
			["buffs"] = {
				["castable"] = 0,
				["inside"] = 1,
				["right"] = 1,
				["size"] = 20,
				["maxrows"] = 2,
			},
			["percent"] = 1,
			["size"] = {
				["width"] = 0,
			},
		},
		["raidpet"] = {
			["enable"] = 1,
			["hunter"] = 1,
			["warlock"] = 1,
		},
		["colour"] = {
			["classic"] = 1,
			["guildList"] = 1,
			["border"] = {
				["a"] = 1,
				["r"] = 0.5,
				["g"] = 0.5,
				["b"] = 0.5,
			},
			["reaction"] = {
				["tapped"] = {
					["r"] = 0.5,
					["g"] = 0.5,
					["b"] = 0.5,
				},
				["enemy"] = {
					["r"] = 1,
					["g"] = 0,
					["b"] = 0,
				},
				["neutral"] = {
					["r"] = 1,
					["g"] = 1,
					["b"] = 0,
				},
				["unfriendly"] = {
					["r"] = 1,
					["g"] = 0.5,
					["b"] = 0,
				},
				["friend"] = {
					["r"] = 0,
					["g"] = 1,
					["b"] = 0,
				},
				["none"] = {
					["r"] = 0.5,
					["g"] = 0.5,
					["b"] = 1,
				},
			},
			["classbarBright"] = 1,
			["class"] = 1,
			["frame"] = {
				["a"] = 1,
				["r"] = 0,
				["g"] = 0,
				["b"] = 0,
			},
			["gradient"] = {
				["enable"] = 1,
				["s"] = {
					["a"] = 1,
					["r"] = 0.25,
					["g"] = 0.25,
					["b"] = 0.25,
				},
				["e"] = {
					["a"] = 0,
					["r"] = 0.1,
					["g"] = 0.1,
					["b"] = 0.1,
				},
			},
			["bar"] = {
				["rage"] = {
					["r"] = 1,
					["g"] = 0,
					["b"] = 0,
				},
				["healthFull"] = {
					["r"] = 0,
					["g"] = 1,
					["b"] = 0,
				},
				["focus"] = {
					["r"] = 1,
					["g"] = 0.5,
					["b"] = 0.25,
				},
				["healthEmpty"] = {
					["r"] = 1,
					["g"] = 0,
					["b"] = 0,
				},
				["mana"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 1,
				},
				["energy"] = {
					["r"] = 1,
					["g"] = 1,
					["b"] = 0,
				},
				["runic_power"] = {
					["r"] = 0,
					["g"] = 0.82,
					["b"] = 1,
				},
			},
		},
		["minimap"] = {
			["enable"] = 1,
			["radius"] = 78,
			["pos"] = 186,
		},
		["combatFlash"] = 1,
		["party"] = {
			["debuffs"] = {
				["curable"] = 0,
				["halfSize"] = 1,
				["below"] = 1,
				["size"] = 28,
			},
			["portrait3D"] = 1,
			["healerMode"] = {
				["type"] = 1,
			},
			["scale"] = 0.5,
			["castBar"] = {
				["castTime"] = 1,
			},
			["threatMode"] = "portraitFrame",
			["anchor"] = "TOP",
			["hitIndicator"] = 1,
			["target"] = {
				["large"] = 1,
				["size"] = 120,
			},
			["buffs"] = {
				["size"] = 15,
				["rows"] = 2,
				["castable"] = 0,
				["maxrows"] = 2,
			},
			["spacing"] = 5,
			["size"] = {
				["width"] = 0,
			},
		},
		["targettarget"] = {
			["debuffs"] = {
				["enable"] = 1,
				["curable"] = 0,
				["size"] = 29,
			},
			["values"] = 1,
			["pvpIcon"] = 1,
			["enable"] = 1,
			["mana"] = 1,
			["healerMode"] = {
				["type"] = 1,
			},
			["scale"] = 0.7,
			["buffs"] = {
				["size"] = 22,
				["castable"] = 0,
				["enable"] = 1,
				["rows"] = 3,
				["wrap"] = 1,
				["maxrows"] = 2,
			},
			["percent"] = 1,
			["size"] = {
				["width"] = 0,
			},
		},
		["transparency"] = {
			["frame"] = 1,
			["text"] = 1,
		},
		["tooltip"] = {
			["enable"] = 1,
			["enableBuffs"] = 1,
			["modifier"] = "all",
		},
		["pettarget"] = {
			["debuffs"] = {
				["enable"] = 1,
				["curable"] = 0,
				["size"] = 29,
			},
			["values"] = 1,
			["pvpIcon"] = 1,
			["enable"] = 1,
			["mana"] = 1,
			["healerMode"] = {
				["type"] = 1,
			},
			["scale"] = 0.7,
			["buffs"] = {
				["size"] = 22,
				["castable"] = 0,
				["enable"] = 1,
				["rows"] = 3,
				["wrap"] = 1,
				["maxrows"] = 2,
			},
			["percent"] = 1,
			["size"] = {
				["width"] = 0,
			},
		},
		["partypet"] = {
			["debuffs"] = {
				["enable"] = 1,
				["curable"] = 0,
				["size"] = 12,
			},
			["name"] = 1,
			["enable"] = 1,
			["scale"] = 0.7,
			["buffs"] = {
				["enable"] = 1,
				["castable"] = 0,
				["size"] = 12,
				["maxrows"] = 2,
			},
			["healerMode"] = {
				["type"] = 1,
			},
			["size"] = {
				["width"] = 0,
			},
		},
		["highlightDebuffs"] = {
			["enable"] = 1,
			["frame"] = 1,
			["border"] = 1,
			["class"] = 1,
		},
		["player"] = {
			["partyNumber"] = 1,
			["debuffs"] = {
				["enable"] = 1,
				["size"] = 45,
			},
			["portrait"] = 1,
			["scale"] = 0.92,
			["castBar"] = {
				["enable"] = 1,
				["precast"] = 1,
				["original"] = 1,
				["castTime"] = 1,
				["inside"] = 1,
			},
			["fullScreen"] = {
				["enable"] = 1,
				["highHP"] = 40,
				["lowHP"] = 30,
			},
			["dockRunes"] = 1,
			["level"] = 1,
			["size"] = {
				["width"] = 0,
			},
			["threat"] = 1,
			["portrait3D"] = 1,
			["withName"] = 1,
			["showRunes"] = 1,
			["classIcon"] = 1,
			["threatMode"] = "portraitFrame",
			["totems"] = {
				["enable"] = true,
				["offsetY"] = 0,
				["offsetX"] = 0,
			},
			["values"] = 1,
			["healerMode"] = {
				["type"] = 2,
			},
			["buffs"] = {
				["enable"] = 1,
				["wrap"] = 1,
				["flash"] = 1,
				["count"] = 40,
				["size"] = 23,
				["rows"] = 10,
				["hideBlizzard"] = 1,
				["cooldown"] = 1,
				["maxrows"] = 2,
			},
			["percent"] = 1,
			["energyTicker"] = 1,
		},
		["pet"] = {
			["debuffs"] = {
				["enable"] = 1,
				["size"] = 20,
			},
			["portrait3D"] = 1,
			["extendPortrait"] = 1,
			["scale"] = 0.7,
			["values"] = 1,
			["threat"] = 1,
			["portrait"] = 1,
			["happiness"] = {
				["enabled"] = 1,
				["flashWhenSad"] = 1,
				["enable"] = 1,
				["onlyWhenSad"] = 1,
			},
			["threatMode"] = "portraitFrame",
			["name"] = 1,
			["hitIndicator"] = 1,
			["castBar"] = {
				["enable"] = 1,
			},
			["buffs"] = {
				["enable"] = 1,
				["size"] = 18,
				["maxrows"] = 2,
			},
			["healerMode"] = {
				["type"] = 1,
			},
			["size"] = {
				["enable"] = 1,
				["width"] = 0,
				["size"] = 20,
			},
		},
		["focustarget"] = {
			["debuffs"] = {
				["enable"] = 1,
				["curable"] = 0,
				["size"] = 26,
			},
			["values"] = 1,
			["pvpIcon"] = 1,
			["enable"] = 1,
			["mana"] = 1,
			["healerMode"] = {
				["type"] = 1,
			},
			["scale"] = 0.7,
			["buffs"] = {
				["size"] = 19,
				["castable"] = 0,
				["enable"] = 1,
				["rows"] = 5,
				["wrap"] = 1,
				["maxrows"] = 2,
			},
			["percent"] = 1,
			["size"] = {
				["width"] = 0,
			},
		},
		["targettargettarget"] = {
			["debuffs"] = {
				["enable"] = 1,
				["curable"] = 0,
				["size"] = 29,
			},
			["values"] = 1,
			["pvpIcon"] = 1,
			["scale"] = 0.7,
			["mana"] = 1,
			["healerMode"] = {
				["type"] = 1,
			},
			["buffs"] = {
				["size"] = 22,
				["castable"] = 0,
				["enable"] = 1,
				["rows"] = 3,
				["wrap"] = 1,
				["maxrows"] = 2,
			},
			["percent"] = 1,
			["size"] = {
				["width"] = 0,
			},
		},
		["buffs"] = {
			["countdown"] = 1,
			["cooldown"] = 1,
			["countdownStart"] = 26,
		},
		["maximumScale"] = 1.5,
		["bar"] = {
			["texture"] = {
				"Smooth", -- [1]
				"Interface\\Addons\\HealBot\\Images\\bar8.tga", -- [2]
			},
			["background"] = 1,
			["fadeTime"] = 0.5,
			["fat"] = 1,
		},
	},
	["savedPositions"] = {
		["WoW Circle 3.3.5a x5"] = {
			["Adolifa"] = {
				["XPerl_Focus"] = {
					["top"] = 212.1599896575994,
					["left"] = 1001.098644110586,
				},
				["XPerl_Raid_Title8"] = {
					["top"] = 481.3333990270002,
					["left"] = 425.6000135636268,
				},
				["XPerl_AdminFrameAnchor"] = {
					["top"] = 501.6666946826391,
					["height"] = 149.9999976748339,
					["left"] = 688.5185777013421,
					["width"] = 140.0000106684094,
				},
				["XPerl_FocusTarget"] = {
					["top"] = 693.3333426803894,
					["left"] = 414.6999959399009,
				},
				["XPerl_Raid_Title4"] = {
					["top"] = 481.3333990270002,
					["left"] = 182.4000038121677,
				},
				["XPerl_Raid_Title1"] = {
					["top"] = 481.3333990270002,
					["left"] = 0,
				},
				["XPerl_Player"] = {
					["top"] = 853.3333611678303,
					["left"] = 19.90989566230991,
				},
				["XPerl_Raid_Title9"] = {
					["top"] = 481.3333990270002,
					["left"] = 486.400047514332,
				},
				["XPerl_Raid_Title5"] = {
					["top"] = 481.3333990270002,
					["left"] = 243.200023757166,
				},
				["XPerl_Player_Pet"] = {
					["top"] = 687.016089815845,
					["left"] = 182.5789681565006,
				},
				["XPerl_OptionsAnchor"] = {
					["top"] = 534.6914156438957,
					["height"] = 540.0000686607884,
					["left"] = 675.5803159914464,
					["width"] = 700.0000358349134,
				},
				["XPerl_Raid_Title6"] = {
					["top"] = 481.3333990270002,
					["left"] = 304.0000016850438,
				},
				["XPerl_Raid_Title2"] = {
					["top"] = 481.3333990270002,
					["left"] = 60.8000059392915,
				},
				["XPerl_Assists_FrameAnchor"] = {
					["top"] = 320.3708404743859,
					["height"] = 123.9999964438636,
					["left"] = 1185.457015850316,
					["width"] = 330.0000088903411,
				},
				["XPerl_Party_Anchor"] = {
					["top"] = 622.1849599910713,
					["left"] = 0,
				},
				["XPerl_Raid_Title10"] = {
					["top"] = 481.3333990270002,
					["left"] = 547.2000534536235,
				},
				["XPerl_Raid_Title7"] = {
					["top"] = 481.3333990270002,
					["left"] = 364.8000076243353,
				},
				["XPerl_PetTarget"] = {
					["top"] = 1116.047711949667,
					["left"] = 233.4999963722936,
				},
				["XPerl_Target"] = {
					["top"] = 853.3333542236913,
					["left"] = 239.9623689753456,
				},
				["XPerl_TargetTarget"] = {
					["top"] = 844.9333426973719,
					["left"] = 412.9999832966964,
				},
				["XPerl_Raid_Title3"] = {
					["top"] = 481.3333990270002,
					["left"] = 121.600011878583,
				},
			},
			["Palamalka"] = {
				["XPerl_Player"] = {
					["top"] = 853.3333380288258,
					["left"] = 18.22953420084267,
				},
				["XPerl_Party_Anchor"] = {
					["top"] = 558.6110572092222,
					["left"] = 0,
				},
				["XPerl_Focus"] = {
					["top"] = 717.3334022775562,
					["left"] = 184.2800065421721,
				},
				["XPerl_Player_Pet"] = {
					["top"] = 791.0333339931989,
					["left"] = 72.09999700091484,
				},
				["XPerl_Target"] = {
					["top"] = 853.333348341245,
					["left"] = 249.6455742597983,
				},
			},
			["Pinichet"] = {
				["XPerl_Player"] = {
					["top"] = 842.6534063793268,
					["left"] = 20.47000034049342,
				},
				["XPerl_Party_Anchor"] = {
					["top"] = 590.2866833376332,
					["left"] = 0,
				},
				["XPerl_Focus"] = {
					["top"] = 717.3334022775562,
					["left"] = 184.2800065421721,
				},
				["XPerl_Player_Pet"] = {
					["top"] = 709.833318333927,
					["left"] = 16.09999872052623,
				},
				["XPerl_Target"] = {
					["top"] = 843.7335287825391,
					["left"] = 233.1577918884429,
				},
			},
			["Saylee"] = {
				["XPerl_Player"] = {
					["top"] = 836.6425139046613,
					["left"] = 25.3406152300598,
				},
				["XPerl_Party_Anchor"] = {
					["top"] = 656.7715593739006,
					["left"] = 0,
				},
				["XPerl_Focus"] = {
					["top"] = 717.3334022775562,
					["left"] = 184.2800065421721,
				},
				["XPerl_Player_Pet"] = {
					["top"] = 90.984040630159,
					["left"] = 21.5320872201309,
				},
				["XPerl_Target"] = {
					["top"] = 839.9012562548951,
					["left"] = 263.8604526646041,
				},
				["XPerl_OptionsAnchor"] = {
					["top"] = 768.567913897183,
					["height"] = 540.0000686607884,
					["left"] = 514.3951509070439,
					["width"] = 700.0000358349134,
				},
			},
			["Godlite"] = {
				["XPerl_Player"] = {
					["top"] = 842.2933526870486,
					["left"] = 21.16000107593279,
				},
				["XPerl_Party_Anchor"] = {
					["top"] = 778.3333928530274,
					["left"] = 0,
				},
				["XPerl_Focus"] = {
					["top"] = 697.3333657294394,
					["left"] = 211.3799975274903,
				},
				["XPerl_Player_Pet"] = {
					["top"] = 791.0333339931989,
					["left"] = 72.09999700091484,
				},
				["XPerl_Target"] = {
					["top"] = 843.3733964274045,
					["left"] = 224.9300010965789,
				},
			},
			["Kadziima"] = {
				["XPerl_Player"] = {
					["top"] = 842.1733198805573,
					["left"] = 21.39000086411028,
				},
				["XPerl_Party_Anchor"] = {
					["top"] = 731.8333670162373,
					["left"] = 0,
				},
				["XPerl_Focus"] = {
					["top"] = 717.3334022775562,
					["left"] = 184.2800065421721,
				},
				["XPerl_Player_Pet"] = {
					["top"] = 722.2925776616473,
					["left"] = 83.16172142519118,
				},
				["XPerl_Target"] = {
					["top"] = 843.7334167368844,
					["left"] = 216.8000086468412,
				},
				["XPerl_OptionsAnchor"] = {
					["top"] = 689.5556302496182,
					["height"] = 540.0000686607884,
					["left"] = 606.839677537753,
					["width"] = 700.0000358349134,
				},
			},
			["Brisom"] = {
				["XPerl_Player"] = {
					["top"] = 842.1733198805573,
					["left"] = 21.39000086411028,
				},
				["XPerl_Party_Anchor"] = {
					["top"] = 439.2844369586252,
					["left"] = 1467.037125996171,
				},
				["XPerl_Focus"] = {
					["top"] = 717.3334022775562,
					["left"] = 184.2800065421721,
				},
				["XPerl_Player_Pet"] = {
					["top"] = 791.0333339931989,
					["left"] = 72.09999700091484,
				},
				["XPerl_Target"] = {
					["top"] = 842.2730996296546,
					["left"] = 269.3985711278249,
				},
			},
			["Drugano"] = {
				["XPerl_Player"] = {
					["top"] = 853.3333380288258,
					["left"] = 18.22951384880005,
				},
				["XPerl_Party_Anchor"] = {
					["top"] = 567.1070375288593,
					["left"] = 0,
				},
				["XPerl_Focus"] = {
					["top"] = 717.3334022775562,
					["left"] = 184.2800065421721,
				},
				["XPerl_Player_Pet"] = {
					["top"] = 709.6506699167245,
					["left"] = 0,
				},
				["XPerl_Target"] = {
					["top"] = 843.8533327403915,
					["left"] = 214.0900111635953,
				},
			},
			["Drmartin"] = {
				["XPerl_Player"] = {
					["top"] = 842.1733198805573,
					["left"] = 21.39000086411028,
				},
				["XPerl_Party_Anchor"] = {
					["top"] = 665.2778979989945,
					["left"] = 0,
				},
				["XPerl_Focus"] = {
					["top"] = 717.3334022775562,
					["left"] = 184.2800065421721,
				},
				["XPerl_Player_Pet"] = {
					["top"] = 648.8110997982529,
					["left"] = 1.779044327786574,
				},
				["XPerl_Target"] = {
					["top"] = 838.3224615302692,
					["left"] = 244.904847266316,
				},
			},
			["Freeby"] = {
				["XPerl_Player"] = {
					["top"] = 842.1733198805573,
					["left"] = 21.39000086411028,
				},
				["XPerl_Party_Anchor"] = {
					["top"] = 633.0678784115728,
					["left"] = 0,
				},
				["XPerl_Focus"] = {
					["top"] = 717.3334022775562,
					["left"] = 184.2800065421721,
				},
				["XPerl_Player_Pet"] = {
					["top"] = 706.3333413237726,
					["left"] = 0,
				},
				["XPerl_Target"] = {
					["top"] = 853.333348341245,
					["left"] = 293.8924886182333,
				},
			},
			["Adamanum"] = {
				["XPerl_Player"] = {
					["top"] = 839.3729092896498,
					["left"] = 23.07036183467752,
				},
				["XPerl_Party_Anchor"] = {
					["top"] = 665.5026643985636,
					["left"] = 0,
				},
				["XPerl_Focus"] = {
					["top"] = 191.8800030968721,
					["left"] = 1021.73711652365,
				},
				["XPerl_Player_Pet"] = {
					["top"] = 312.2184004382582,
					["left"] = 1413.72943564941,
				},
				["XPerl_Target"] = {
					["top"] = 840.6928111963747,
					["left"] = 248.852387303308,
				},
				["XPerl_OptionsAnchor"] = {
					["top"] = 711.6790444606644,
					["height"] = 540.0000686607884,
					["left"] = 348.4690891387318,
					["width"] = 700.0000358349134,
				},
			},
		},
	},
	["ConfigVersion"] = "3.0.9",
}
XPerlConfigSavePerCharacter = nil


RecountDB = {
	["profileKeys"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = "Drugano - WoW Circle 3.3.5a x5",
		["Saylee - WoW Circle 3.3.5a x5"] = "Saylee - WoW Circle 3.3.5a x5",
		["Godlite - WoW Circle 3.3.5a x5"] = "Godlite - WoW Circle 3.3.5a x5",
		["Freeby - WoW Circle 3.3.5a x5"] = "Freeby - WoW Circle 3.3.5a x5",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Palamalka - WoW Circle 3.3.5a x5",
		["Kadziima - WoW Circle 3.3.5a x5"] = "Kadziima - WoW Circle 3.3.5a x5",
		["Brisom - WoW Circle 3.3.5a x5"] = "Brisom - WoW Circle 3.3.5a x5",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa - WoW Circle 3.3.5a x5",
		["Adamanum - WoW Circle 3.3.5a x5"] = "Adamanum - WoW Circle 3.3.5a x5",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Pinichet - WoW Circle 3.3.5a x5",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Drmartin - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -328.6909874030021,
					["h"] = 198.4197388551197,
					["w"] = 260.8889720173777,
					["x"] = 626.9625166121153,
				},
			},
			["DetailWindowX"] = 0,
			["LastInstanceName"] = "Очищение Стратхольма",
			["CurDataSet"] = "CurrentFightData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["MainWindowHeight"] = 198.4197388551197,
			["MainWindowWidth"] = 260.888989524511,
			["GraphWindowX"] = 0,
		},
		["Saylee - WoW Circle 3.3.5a x5"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -295.1666960161903,
					["x"] = 647.0185484657972,
					["w"] = 225.0000315265174,
					["h"] = 262.9999996580638,
				},
			},
			["MainWindowMode"] = 2,
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["DetailWindowX"] = 0,
			["GraphWindowX"] = 0,
			["LastInstanceName"] = "Остров Завоеваний",
			["CurDataSet"] = "OverallData",
			["MainWindowWidth"] = 224.6172730711362,
			["MainWindowHeight"] = 262.790089129773,
		},
		["Godlite - WoW Circle 3.3.5a x5"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -283.2598495576474,
					["x"] = 670.0251625376619,
					["w"] = 179.5063800849246,
					["h"] = 203.9506624364144,
				},
			},
			["DetailWindowX"] = 0,
			["MainWindowHeight"] = 203.9506624364144,
			["CurDataSet"] = "OverallData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["MainWindowWidth"] = 179.5063800849246,
			["GraphWindowX"] = 0,
		},
		["Freeby - WoW Circle 3.3.5a x5"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -290.0805586635656,
					["x"] = 633.4383351919845,
					["w"] = 256.901389772319,
					["h"] = 286.2345215912534,
				},
			},
			["MainWindowMode"] = 2,
			["LastInstanceName"] = "Цитадель Ледяной Короны",
			["CurDataSet"] = "LastFightData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["MainWindowHeight"] = 286.2345215912534,
			["GraphWindowX"] = 0,
			["MainWindowWidth"] = 256.901389772319,
			["DetailWindowX"] = 0,
		},
		["Palamalka - WoW Circle 3.3.5a x5"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -312.6287747106177,
					["h"] = 228.0000013677448,
					["w"] = 212.0000396645989,
					["x"] = 654.8763101199914,
				},
			},
			["DetailWindowX"] = 0,
			["LastInstanceName"] = "Цитадель Ледяной Короны",
			["CurDataSet"] = "LastFightData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["MainWindowHeight"] = 228.2223419606799,
			["MainWindowWidth"] = 211.8395342664863,
			["GraphWindowX"] = 0,
		},
		["Kadziima - WoW Circle 3.3.5a x5"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = 156.4444784860926,
					["x"] = 359.5059711292328,
					["w"] = 140.0000106684094,
					["h"] = 200.0000027354896,
				},
			},
			["DetailWindowX"] = 0,
			["LastInstanceName"] = "Глубины Черной горы",
			["CurDataSet"] = "OverallData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["MainWindowVis"] = false,
			["GraphWindowX"] = 0,
		},
		["Brisom - WoW Circle 3.3.5a x5"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -364.9074819811592,
					["x"] = 677.8334840474112,
					["w"] = 225.0001190621839,
					["h"] = 264.9999970593487,
				},
			},
			["DetailWindowX"] = 0,
			["LastInstanceName"] = "Рубиновое святилище",
			["CurDataSet"] = "LastFightData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["GraphWindowX"] = 0,
			["MainWindowWidth"] = 225.0494891780955,
			["MainWindowHeight"] = 264.740751429413,
		},
		["Adolifa - WoW Circle 3.3.5a x5"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -298.876527591413,
					["x"] = 651.09883098169,
					["w"] = 231.9998911275148,
					["h"] = 258.0000149084182,
				},
			},
			["DetailWindowX"] = 824.8394117849405,
			["LastInstanceName"] = "Вершина Утгард",
			["SegmentBosses"] = true,
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = -59.9999876902969,
			["CurDataSet"] = "OverallData",
			["GraphWindowX"] = 0,
			["MainWindowWidth"] = 231.654317823267,
			["MainWindowHeight"] = 257.9999623870183,
		},
		["Adamanum - WoW Circle 3.3.5a x5"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["RowHeight"] = 20,
				["BarText"] = {
					["RankNum"] = false,
					["NumFormat"] = 3,
				},
				["Buttons"] = {
					["CloseButton"] = false,
				},
				["Position"] = {
					["y"] = -317.4667211965639,
					["h"] = 271.00002427747,
					["w"] = 289.9999733289766,
					["x"] = 642.518534668655,
				},
			},
			["DetailWindowX"] = 3424847158.253083,
			["MainWindowHeight"] = 270.9876467342255,
			["BarTexture"] = "Flat",
			["RealtimeWindows"] = {
				["Realtime_FPS_FPS"] = {
					"FPS", -- [1]
					"FPS", -- [2]
					"", -- [3]
					256.3950484629591, -- [4]
					-55.30864057041528, -- [5]
					284.5434025428154, -- [6]
					214.6173385861116, -- [7]
					false, -- [8]
				},
				["Realtime_Latency_LAG"] = {
					"Latency", -- [1]
					"LAG", -- [2]
					"", -- [3]
					0, -- [4]
					0, -- [5]
					200.0000027354896, -- [6]
					232.0000136774479, -- [7]
					false, -- [8]
				},
				["Realtime_Upstream Traffic_UP_TRAFFIC"] = {
					"Upstream Traffic", -- [1]
					"UP_TRAFFIC", -- [2]
					"", -- [3]
					0, -- [4]
					0, -- [5]
					200.0000027354896, -- [6]
					232.0000136774479, -- [7]
					false, -- [8]
				},
				["Realtime_!RAID_HEALING"] = {
					"!RAID", -- [1]
					"HEALING", -- [2]
					"Raid HPS", -- [3]
					600.1655012447017, -- [4]
					-131.160119578353, -- [5]
					398.0246055919835, -- [6]
					210.905546211959, -- [7]
					false, -- [8]
				},
				["Realtime_Downstream Traffic_DOWN_TRAFFIC"] = {
					"Downstream Traffic", -- [1]
					"DOWN_TRAFFIC", -- [2]
					"", -- [3]
					0, -- [4]
					0, -- [5]
					200.0000027354896, -- [6]
					232.0000136774479, -- [7]
					false, -- [8]
				},
				["Realtime_Bandwidth Available_AVAILABLE_BANDWIDTH"] = {
					"Bandwidth Available", -- [1]
					"AVAILABLE_BANDWIDTH", -- [2]
					"", -- [3]
					255.9998074215337, -- [4]
					-22.1234142110462, -- [5]
					200.0000552568895, -- [6]
					232.0000136774479, -- [7]
					false, -- [8]
				},
			},
			["BarTextColorSwap"] = false,
			["LastInstanceName"] = "Испытание крестоносца",
			["SegmentBosses"] = true,
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = -2247584925.011745,
			["CurDataSet"] = "LastFightData",
			["Scaling"] = 0.8,
			["MainWindowWidth"] = 289.9383482197537,
			["GraphWindowX"] = 0,
		},
		["Pinichet - WoW Circle 3.3.5a x5"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -267.7645309719311,
					["x"] = 648.7338273581921,
					["w"] = 227.0000464349356,
					["h"] = 248.0000279019937,
				},
			},
			["DetailWindowX"] = 0,
			["LastInstanceName"] = "Цитадель Ледяной Короны",
			["CurDataSet"] = "LastFightData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["GraphWindowX"] = 0,
			["MainWindowWidth"] = 227.2964772160047,
			["MainWindowHeight"] = 248.3210386982188,
		},
		["Drmartin - WoW Circle 3.3.5a x5"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -327.8518836341882,
					["x"] = 638.3210046413736,
					["w"] = 236.3950919572435,
					["h"] = 202.3703985560445,
				},
			},
			["MainWindowMode"] = 4,
			["LastInstanceName"] = "Гундрак",
			["CurDataSet"] = "OverallData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = -324.7407610036265,
			["MainWindowHeight"] = 202.3703985560445,
			["GraphWindowX"] = 0,
			["MainWindowWidth"] = 236.3950744501102,
			["DetailWindowX"] = 700.0494759793583,
		},
	},
}


MSBTProfiles_SavedVars = {
	["profiles"] = {
		["Default"] = {
			["creationVersion"] = "5.4.78",
		},
	},
}
MSBT_SavedMedia = {
	["fonts"] = {
	},
	["sounds"] = {
	},
}

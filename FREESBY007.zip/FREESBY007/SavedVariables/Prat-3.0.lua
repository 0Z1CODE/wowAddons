
Prat3DB = {
	["namespaces"] = {
		["Prat_ChatTabs"] = {
		},
		["Prat_AltNames"] = {
		},
		["Prat_PlayerNames"] = {
		},
		["Prat_Frames"] = {
			["profiles"] = {
				["Default"] = {
					["minchatwidthdefault"] = 296.0000005470979,
					["minchatwidth"] = 73,
					["framealpha"] = 0.54,
					["maxchatheightdefault"] = 400.0000054709792,
					["maxchatheight"] = 750,
					["maxchatwidthdefault"] = 608.0000503330083,
					["initialized"] = true,
					["minchatheightdefault"] = 120.0000016412938,
				},
			},
		},
		["Prat_ChannelColorMemory"] = {
			["profiles"] = {
				["Default"] = {
					["colors"] = {
						["гильдии"] = {
							["b"] = 0.752941220998764,
							["g"] = 0.752941220998764,
							["r"] = 1.000000059138984,
						},
					},
				},
			},
		},
		["Prat_Editbox"] = {
		},
		["Prat_Fading"] = {
		},
		["Prat_Font"] = {
		},
		["Prat_Scroll"] = {
		},
		["Prat_Paragraph"] = {
		},
		["Prat_Alias"] = {
		},
		["Prat_UrlCopy"] = {
		},
		["Prat_TellTarget"] = {
		},
		["Prat_Sounds"] = {
		},
		["Prat_History"] = {
		},
		["Prat_Timestamps"] = {
		},
		["Prat_PopupMessage"] = {
		},
		["Prat_CopyChat"] = {
		},
		["Prat_ChatLog"] = {
		},
		["Prat_ChannelSticky"] = {
		},
		["Prat_Buttons"] = {
		},
		["Prat_ServerNames"] = {
		},
		["Prat_ChannelNames"] = {
		},
	},
	["profileKeys"] = {
		["Adamanum - WoW Circle 3.3.5a x5"] = "Default",
		["Saylee - WoW Circle 3.3.5a x5"] = "Default",
		["Godlite - WoW Circle 3.3.5a x5"] = "Default",
		["Freeby - WoW Circle 3.3.5a x5"] = "Default",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Default",
		["Kadziima - WoW Circle 3.3.5a x5"] = "Default",
		["Drugano - WoW Circle 3.3.5a x5"] = "Default",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Default",
		["Brisom - WoW Circle 3.3.5a x5"] = "Default",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Default",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["modules"] = {
				["PopupMessage"] = 2,
				["AltNames"] = 2,
				["Sounds"] = 2,
				["Paragraph"] = 2,
				["Alias"] = 2,
				["ChatLog"] = 2,
			},
		},
	},
}

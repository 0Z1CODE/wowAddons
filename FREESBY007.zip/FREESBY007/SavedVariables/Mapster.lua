
MapsterDB = {
	["namespaces"] = {
		["FogClear"] = {
		},
		["Coords"] = {
		},
		["BattleMap"] = {
		},
	},
	["profileKeys"] = {
		["Adamanum - WoW Circle 3.3.5a x5"] = "Default",
		["Saylee - WoW Circle 3.3.5a x5"] = "Default",
		["Godlite - WoW Circle 3.3.5a x5"] = "Default",
		["Freeby - WoW Circle 3.3.5a x5"] = "Default",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Default",
		["Kadziima - WoW Circle 3.3.5a x5"] = "Default",
		["Drugano - WoW Circle 3.3.5a x5"] = "Default",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Default",
		["Brisom - WoW Circle 3.3.5a x5"] = "Default",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Default",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["arrowScale"] = 0.8700000047683716,
			["point"] = "TOPLEFT",
			["miniMap"] = true,
			["scale"] = 0.7172850370407105,
			["mini"] = {
				["y"] = 75.34004363223096,
				["x"] = 4.549261536649722,
				["point"] = "LEFT",
				["scale"] = 0.8179171085357666,
				["alpha"] = 1,
				["disableMouse"] = false,
			},
			["y"] = -40.86550572022247,
			["x"] = -4.771777574822688,
		},
	},
}

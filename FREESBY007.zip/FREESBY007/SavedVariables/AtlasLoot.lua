
AtlasLootOptions = nil
AtlasLootDB = {
	["profileKeys"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = "Drugano - WoW Circle 3.3.5a x5",
		["Saylee - WoW Circle 3.3.5a x5"] = "Saylee - WoW Circle 3.3.5a x5",
		["Godlite - WoW Circle 3.3.5a x5"] = "Godlite - WoW Circle 3.3.5a x5",
		["Freeby - WoW Circle 3.3.5a x5"] = "Freeby - WoW Circle 3.3.5a x5",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Palamalka - WoW Circle 3.3.5a x5",
		["Kadziima - WoW Circle 3.3.5a x5"] = "Kadziima - WoW Circle 3.3.5a x5",
		["Brisom - WoW Circle 3.3.5a x5"] = "Brisom - WoW Circle 3.3.5a x5",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa - WoW Circle 3.3.5a x5",
		["Adamanum - WoW Circle 3.3.5a x5"] = "Adamanum - WoW Circle 3.3.5a x5",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Pinichet - WoW Circle 3.3.5a x5",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Drmartin - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = {
			["AtlasType"] = "Unknown",
		},
		["Saylee - WoW Circle 3.3.5a x5"] = {
			["AtlasType"] = "Unknown",
		},
		["Godlite - WoW Circle 3.3.5a x5"] = {
			["AtlasType"] = "Unknown",
		},
		["Freeby - WoW Circle 3.3.5a x5"] = {
			["AtlasType"] = "Unknown",
		},
		["Palamalka - WoW Circle 3.3.5a x5"] = {
			["AtlasType"] = "Unknown",
		},
		["Kadziima - WoW Circle 3.3.5a x5"] = {
			["AtlasType"] = "Unknown",
		},
		["Brisom - WoW Circle 3.3.5a x5"] = {
			["AtlasType"] = "Unknown",
		},
		["Adolifa - WoW Circle 3.3.5a x5"] = {
			["AtlasType"] = "Unknown",
		},
		["Adamanum - WoW Circle 3.3.5a x5"] = {
			["LoadAllLoDStartup"] = true,
			["Opaque"] = 1,
			["ItemIDs"] = 1,
			["AtlasType"] = "Unknown",
		},
		["Pinichet - WoW Circle 3.3.5a x5"] = {
			["AtlasType"] = "Unknown",
		},
		["Drmartin - WoW Circle 3.3.5a x5"] = {
			["AtlasType"] = "Unknown",
		},
	},
}
AtlasLootWishList = {
	["Options"] = {
		["Adolifa"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["markInTable"] = "own",
			["AllowShareWishlist"] = true,
		},
		["Palamalka"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["AllowShareWishlist"] = true,
			["markInTable"] = "own",
		},
		["Pinichet"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["markInTable"] = "own",
			["AllowShareWishlist"] = true,
		},
		["Saylee"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["AllowShareWishlist"] = true,
			["markInTable"] = "own",
		},
		["Godlite"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["AllowShareWishlist"] = true,
			["markInTable"] = "own",
		},
		["Kadziima"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["AllowShareWishlist"] = true,
			["markInTable"] = "own",
		},
		["Freeby"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["AllowShareWishlist"] = true,
			["markInTable"] = "own",
		},
		["Drugano"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["markInTable"] = "own",
			["AllowShareWishlist"] = true,
		},
		["Brisom"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["AllowShareWishlist"] = true,
			["markInTable"] = "own",
		},
		["Drmartin"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["AllowShareWishlist"] = true,
			["markInTable"] = "own",
		},
		["Adamanum"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["AllowShareWishlist"] = true,
			["markInTable"] = "own",
		},
	},
	["Shared"] = {
	},
	["Own"] = {
		["Adolifa"] = {
		},
		["Palamalka"] = {
		},
		["Pinichet"] = {
		},
		["Saylee"] = {
		},
		["Godlite"] = {
		},
		["Kadziima"] = {
		},
		["Freeby"] = {
		},
		["Drugano"] = {
		},
		["Brisom"] = {
		},
		["Drmartin"] = {
		},
		["Adamanum"] = {
		},
	},
}

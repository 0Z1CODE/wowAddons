
_NPCScanOverlayOptions = {
	["ModulesAlpha"] = {
		["WorldMap"] = 0.5,
		["Minimap"] = 0.5,
		["AlphaMap3"] = 0.5,
		["BattlefieldMinimap"] = 0.800000011920929,
	},
	["Version"] = "3.3.5.1",
	["ShowAll"] = false,
	["ModulesExtra"] = {
		["Minimap"] = {
			["RangeRing"] = true,
		},
	},
	["Modules"] = {
		["WorldMap"] = true,
		["Minimap"] = true,
		["AlphaMap3"] = true,
		["BattlefieldMinimap"] = true,
	},
}

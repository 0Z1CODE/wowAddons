
MFClipDB = {
	["profileKeys"] = {
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Adolifa - WoW Circle 3.3.5a x5"] = {
			["fSparkHeightMulti"] = 1,
			["lbtextcolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["iFontsizeClip"] = 0,
			["strSelSixthPre"] = "",
			["strSound"] = "MONEYFRAMEOPEN",
			["lblagcolor"] = {
				0.35, -- [1]
				0.65, -- [2]
				0.9, -- [3]
				0.65, -- [4]
			},
			["strLBooCconf"] = "on showcb cast mb vt dp swp buttons",
			["fWFCL"] = 1000,
			["strSelFirstPre"] = "",
			["bSticky"] = false,
			["bShowAnchor"] = true,
			["strLBinCconf"] = "on showcb cast mb vt dp swp buttons",
			["strSelSixthFixed"] = "",
			["sparkcolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["fLBWidth"] = 250,
			["bShowSparkForAll"] = true,
			["strSelThird"] = "HitsCrits",
			["iTotalMFDmg"] = 0,
			["strSelSecondFixed"] = "",
			["strSelFirstFixed"] = "",
			["strSelSixthPost"] = "",
			["iTotalMFClipped"] = 0,
			["strSelFirst"] = "Dmg",
			["strSelFirstDesc"] = "Spell damage",
			["bShowCombat"] = true,
			["iFontsizeNonClip"] = 0,
			["strSelThirdColor"] = "|c00ffff00",
			["bfWFCLadj"] = true,
			["fSparkWidthMulti"] = 1,
			["iTotalMFCrit"] = 0,
			["bHideBlizzCB"] = true,
			["buttonanchor"] = {
				["y"] = 312.834035810598,
				["x"] = 1064.137778006146,
				["s"] = 0.8999999761581421,
			},
			["fLBScale"] = 1,
			["bMFTS"] = true,
			["bLiveButtonsCombat"] = false,
			["optver"] = 1.2,
			["strSelFirstColor"] = "|c00a000a0",
			["bSound"] = true,
			["strSelFifthFixed"] = "",
			["fUCW"] = 300,
			["strCT"] = "Blizzard",
			["iTotalMFHit"] = 0,
			["strSelFourthDesc"] = "Clipped",
			["fMinDotCount"] = 10,
			["iSpec2Cmd"] = 0,
			["iFontoutlineClip"] = 0,
			["strSelFifthColor"] = "|c00ffffff",
			["anchor"] = {
				["y"] = 497.3454588202355,
				["x"] = 1071.571656751902,
				["s"] = 0.8999999761581421,
			},
			["bMFDS"] = true,
			["strSelSecondColor"] = "|c00ffff00",
			["strSelSecondPre"] = " (",
			["strSelSecondPost"] = ")",
			["iSpec1Cmd"] = 0,
			["fLButtonsScale"] = 1,
			["strSelSecond"] = "Spell",
			["bEnabled"] = false,
			["bHideCastbarWNC"] = false,
			["lbbarbgcolor"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.35, -- [3]
				0.4, -- [4]
			},
			["strSelThirdPost"] = "]",
			["lbbordercolor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.75, -- [4]
			},
			["font"] = "Desyrel",
			["strSelThirdDesc"] = "Number of hits & crits",
			["strSelThirdPre"] = " [",
			["bCT"] = true,
			["strSelFourthPre"] = "",
			["fLBHeight"] = 16,
			["strSelFourth"] = "Clip",
			["strSelFifthDesc"] = "Unused",
			["fLBmax"] = 0.1,
			["fmFL"] = 30,
			["bHideInVehicle"] = false,
			["fLBSpacing"] = -1,
			["strSelFifth"] = "Static",
			["strLButtons"] = "mf ms mb vt dp swp row",
			["strLBconf"] = "on showcb cast mb vt dp swp buttons",
			["strSelFourthPost"] = "",
			["bLiveButtonsEnabled"] = true,
			["strSelThirdFixed"] = "",
			["iTotalMFCount"] = 0,
			["strSelSixthDesc"] = "Unused",
			["iFontoutlineNonClip"] = 0,
			["strSelSixth"] = "Static",
			["strSelSixthColor"] = "|c00ffffff",
			["bMFCE"] = true,
			["strSelFirstPost"] = "",
			["bLiveBarsEnabled"] = true,
			["strSelSecondDesc"] = "Spell name",
			["bHideLBDetails"] = false,
			["bShowButtonAnchor"] = true,
			["strSelFifthPost"] = "",
			["fLBBorder"] = 1,
			["strSelFifthPre"] = "",
			["bShowIcon"] = false,
			["lbtexture"] = "Waterline",
			["strSelFourthFixed"] = " (clipped)",
			["bLDBOutputOnly"] = false,
			["iZoom"] = 5,
			["strSelFourthColor"] = "|c00ffffff",
			["lbbarcolor"] = {
				0.2, -- [1]
				0.3, -- [2]
				0.5, -- [3]
				0.7, -- [4]
			},
		},
	},
}

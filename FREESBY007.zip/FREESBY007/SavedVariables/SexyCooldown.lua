
SexyCooldownDB = {
	["profileKeys"] = {
		["Adamanum - WoW Circle 3.3.5a x5"] = "Adamanum - WoW Circle 3.3.5a x5",
		["Saylee - WoW Circle 3.3.5a x5"] = "Saylee - WoW Circle 3.3.5a x5",
		["Godlite - WoW Circle 3.3.5a x5"] = "Godlite - WoW Circle 3.3.5a x5",
		["Freeby - WoW Circle 3.3.5a x5"] = "Freeby - WoW Circle 3.3.5a x5",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Palamalka - WoW Circle 3.3.5a x5",
		["Brisom - WoW Circle 3.3.5a x5"] = "Brisom - WoW Circle 3.3.5a x5",
		["Drugano - WoW Circle 3.3.5a x5"] = "Drugano - WoW Circle 3.3.5a x5",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa - WoW Circle 3.3.5a x5",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Pinichet - WoW Circle 3.3.5a x5",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Drmartin - WoW Circle 3.3.5a x5",
	},
	["global"] = {
		["dbVersion"] = 3,
	},
	["profiles"] = {
		["Adamanum - WoW Circle 3.3.5a x5"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["y"] = -191.8395602536374,
						["x"] = 640.8084181409188,
						["fontColor"] = {
						},
						["borderColor"] = {
						},
						["height"] = 33.00000088903411,
						["name"] = "Bar 0",
						["backgroundColor"] = {
						},
						["width"] = 227.000011420669,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
						["item:6948"] = "Камень возвращения",
					},
				}, -- [1]
			},
		},
		["Saylee - WoW Circle 3.3.5a x5"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["y"] = -358.3704628400496,
						["x"] = 404.5677916207987,
						["fontColor"] = {
						},
						["borderColor"] = {
						},
						["height"] = 31.00000129935755,
						["name"] = "Bar 0",
						["backgroundColor"] = {
						},
						["width"] = 221.000001709681,
					},
				}, -- [1]
			},
		},
		["Godlite - WoW Circle 3.3.5a x5"] = {
			["bars"] = {
				{
					["bar"] = {
						["y"] = -164.0985446443183,
						["x"] = 673.5799509403621,
						["fontColor"] = {
						},
						["borderColor"] = {
						},
						["height"] = 29.83953221486915,
						["name"] = "Bar 0",
						["backgroundColor"] = {
						},
						["width"] = 180.5681527054231,
					},
					["events"] = {
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
		["Freeby - WoW Circle 3.3.5a x5"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["y"] = -313.8269804209385,
						["x"] = 310.5176507806984,
						["fontColor"] = {
						},
						["borderColor"] = {
						},
						["height"] = 39.00000184645547,
						["name"] = "Bar 0",
						["backgroundColor"] = {
						},
						["width"] = 299.0000229097252,
					},
				}, -- [1]
			},
		},
		["Palamalka - WoW Circle 3.3.5a x5"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["y"] = -407.5235975298803,
						["x"] = 299.7785651276643,
						["fontColor"] = {
						},
						["borderColor"] = {
						},
						["height"] = 23.00000075225963,
						["name"] = "Bar 0",
						["backgroundColor"] = {
						},
						["width"] = 212.0000046503323,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
						["item:6948"] = "Камень возвращения",
					},
				}, -- [1]
			},
		},
		["Brisom - WoW Circle 3.3.5a x5"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["y"] = -153.4447362375981,
						["x"] = 641.468927266136,
						["fontColor"] = {
						},
						["borderColor"] = {
						},
						["height"] = 33.00000088903411,
						["name"] = "Bar 0",
						["backgroundColor"] = {
						},
						["width"] = 200.0000027354896,
					},
				}, -- [1]
			},
		},
		["Drugano - WoW Circle 3.3.5a x5"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["y"] = -197.1605382923748,
						["x"] = 625.4323931615222,
						["fontColor"] = {
						},
						["borderColor"] = {
						},
						["height"] = 28.25925739254091,
						["name"] = "Bar 0",
						["backgroundColor"] = {
						},
						["width"] = 244.5681395750732,
					},
				}, -- [1]
			},
		},
		["Adolifa - WoW Circle 3.3.5a x5"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["y"] = -174.6539629618815,
						["x"] = 609.9196724853036,
						["fontColor"] = {
						},
						["borderColor"] = {
						},
						["height"] = 31.00000129935755,
						["name"] = "Bar 0",
						["backgroundColor"] = {
						},
						["width"] = 214.9999744915597,
					},
				}, -- [1]
			},
		},
		["Pinichet - WoW Circle 3.3.5a x5"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["blacklist"] = {
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["bar"] = {
						["y"] = -333.0798200129922,
						["x"] = 297.9747001407613,
						["fontColor"] = {
						},
						["borderColor"] = {
						},
						["height"] = 25.0000003419362,
						["name"] = "Bar 0",
						["backgroundColor"] = {
						},
						["width"] = 230.000016276163,
					},
				}, -- [1]
			},
		},
		["Drmartin - WoW Circle 3.3.5a x5"] = {
			["bars"] = {
				{
					["events"] = {
					},
					["bar"] = {
						["y"] = -343.0620547862485,
						["x"] = 366.617018533831,
						["fontColor"] = {
						},
						["borderColor"] = {
						},
						["height"] = 35.00000266710234,
						["name"] = "Bar 0",
						["backgroundColor"] = {
						},
						["width"] = 205.0000224994018,
					},
					["eventColors"] = {
					},
					["icon"] = {
						["fontColor"] = {
						},
						["borderColor"] = {
						},
					},
					["blacklist"] = {
					},
				}, -- [1]
			},
		},
	},
}

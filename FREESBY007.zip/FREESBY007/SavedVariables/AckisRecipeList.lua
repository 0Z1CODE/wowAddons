
ARLDB2 = {
	["global"] = {
		["tradeskill"] = {
			["WoW Circle 3.3.5a x5"] = {
				["Adolifa"] = {
					["Кулинария"] = "|cffffd000|Htrade:51296:450:450:5D3996:2PAAedDAs+IBDQ3QOAo//HoAgPAG8/B|h[Кулинария]|h|r",
					["Наложение чар"] = "|cffffd000|Htrade:51313:450:450:5D3996:47Kbb6a8f5Z7nsynvLJPgAAAQAGABsAA4XzS807v2bVvH2//vtz|h[Наложение чар]|h|r",
					["Портняжное дело"] = "|cffffd000|Htrade:51309:450:450:5D3996:4+/+rqoI6dih4/PQ17CRtTFIyV3nNzlLAAAAA4HA8/EABAAEBARAKgAA+/////v3z/////wM8A|h[Портняжное дело]|h|r",
				},
				["Palamalka"] = {
					["Ювелирное дело"] = "|cffffd000|Htrade:51311:450:450:430627:8f6UtqMsJyjpmMHAAAAwHAQAg/Bh/vBAAAAAAg+BAAAA6/37v7re2f1eDiSCgAKACAAYigxmAEA8/D8Pg/BAACAIBAAAAAA|h[Ювелирное дело]|h|r",
					["Наложение чар"] = "|cffffd000|Htrade:28029:342:375:430627:47Kbb6a8f5Z7msynvLJPACAAQBBAAAAAYEgAQAAAAAAAAAAAAAC|h[Наложение чар]|h|r",
				},
				["Brisom"] = {
					["Алхимия"] = "|cffffd000|Htrade:51304:450:450:437795:WNtCwRvHdFc/OAMAAEgDBACQCAk/oAC/7///Dc6Px//n|h[Алхимия]|h|r",
				},
				["Pinichet"] = {
					["Кулинария"] = "|cffffd000|Htrade:51296:404:450:6A05C0:GAAAGQBAEANBDIAQAAo/9DIAgAAAUqA|h[Кулинария]|h|r",
					["Портняжное дело"] = "|cffffd000|Htrade:51309:432:450:6A05C0:4+/+vqoIydih6/PQ07CRtzBIz13nNzlLAAAAA4PA8PAQAAAAAAFACAAA+////2PWzPw//fwAAA|h[Портняжное дело]|h|r",
					["Инженерное дело"] = "|cffffd000|Htrade:51306:450:450:6A05C0:4/9+svWuCL++NZDA62JfJRCOMADAAAnAA5fAgbIBIBA45//v/DphXB|h[Инженерное дело]|h|r",
				},
				["Saylee"] = {
					["Портняжное дело"] = "|cffffd000|Htrade:51309:441:450:356B56:4+/+rqoI6dih4/PQ07SRtTBIyV3nNzlLAAAAA49B8DDQAAAAIAFAAPEA+/////PWzv6//fwAAB|h[Портняжное дело]|h|r",
					["Инженерное дело"] = "|cffffd000|Htrade:51306:450:450:356B56:4/9+svWuCr6+NZzn/2LfJRCOPADAAAnAgxfg9bIBBBA45/3//JIjXF|h[Инженерное дело]|h|r",
				},
				["Adamanum"] = {
					["Начертание"] = "|cffffd000|Htrade:45363:450:450:44F304:g////7PJt/w////s8/D5/fz+/z+/34//+//78/fg/////UQIAEAAAA/////PdgY///////////c|h[Начертание]|h|r",
					["Кулинария"] = "|cffffd000|Htrade:51296:450:450:44F304:GOAAWRBAEIBjACBQAAo/9DIAgAAAUKA|h[Кулинария]|h|r",
					["Ювелирное дело"] = "|cffffd000|Htrade:51311:450:450:44F304:8f6UsqMsJyjpmMHAgAAwHAAAg/Bg/vBAAAAAAA+BAAAA6/37v7re2f1eDCaUxgmRWOD5i3xmQAC8/D8Pg/BAASIERAAAAAA|h[Ювелирное дело]|h|r",
				},
			},
		},
	},
	["profileKeys"] = {
		["Adamanum - WoW Circle 3.3.5a x5"] = "Adamanum - WoW Circle 3.3.5a x5",
		["Saylee - WoW Circle 3.3.5a x5"] = "Saylee - WoW Circle 3.3.5a x5",
		["Godlite - WoW Circle 3.3.5a x5"] = "Godlite - WoW Circle 3.3.5a x5",
		["Freeby - WoW Circle 3.3.5a x5"] = "Freeby - WoW Circle 3.3.5a x5",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Palamalka - WoW Circle 3.3.5a x5",
		["Brisom - WoW Circle 3.3.5a x5"] = "Brisom - WoW Circle 3.3.5a x5",
		["Drugano - WoW Circle 3.3.5a x5"] = "Drugano - WoW Circle 3.3.5a x5",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa - WoW Circle 3.3.5a x5",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Pinichet - WoW Circle 3.3.5a x5",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Drmartin - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Adamanum - WoW Circle 3.3.5a x5"] = {
		},
		["Saylee - WoW Circle 3.3.5a x5"] = {
		},
		["Godlite - WoW Circle 3.3.5a x5"] = {
		},
		["Freeby - WoW Circle 3.3.5a x5"] = {
		},
		["Palamalka - WoW Circle 3.3.5a x5"] = {
		},
		["Brisom - WoW Circle 3.3.5a x5"] = {
		},
		["Drugano - WoW Circle 3.3.5a x5"] = {
		},
		["Adolifa - WoW Circle 3.3.5a x5"] = {
		},
		["Pinichet - WoW Circle 3.3.5a x5"] = {
		},
		["Drmartin - WoW Circle 3.3.5a x5"] = {
		},
	},
}

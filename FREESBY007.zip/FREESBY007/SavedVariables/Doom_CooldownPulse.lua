
DCP_Saved = {
	["fadeInTime"] = 0.3,
	["petOverlay"] = {
		1, -- [1]
		1, -- [2]
		1, -- [3]
	},
	["holdTime"] = 0,
	["fadeOutTime"] = 0.7,
	["maxAlpha"] = 0.7,
	["x"] = 682.6667133523555,
	["iconSize"] = 75,
	["animScale"] = 1.5,
	["ignoredSpells"] = "",
	["y"] = 383.9999912464334,
}

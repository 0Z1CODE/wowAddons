
OvaleDB = {
	["profileKeys"] = {
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Adolifa - WoW Circle 3.3.5a x5"] = {
			["top"] = 158.6675167656447,
			["code"] = "# Define constants for easier addressing of spells\nDefine(SWP 589) # Shadow Word: Pain\nDefine(VT 34916) # Vampiric Touch\nDefine(VE 15286) # Vampiric Embrace\nDefine(SF 15473) # Shadowform\nDefine(MF 15407) # Mind Flay\n#Define(MB 8092) # Mind Blast\nDefine(DP 2944) # Devouring Plague\nDefine(SW 15257) # Shadow Weaving\nDefine(IF 48168) # Inner Fire\nDefine(Focus 14751) # Inner Focus\nDefine(Dispersion 47585)\nDefine(Shadowfiend 34433)\nDefine(Bloodlust 2825)\nDefine(Heroism 32182)\n\nAddCheckBox(multidot L(multidot))\n\n# Spells with cast time that add buff or debuff\nSpellAddTargetDebuff(SWP SWP=18)\nSpellInfo(SWP duration=18)\nSpellAddBuff(SWP SW=15)\nSpellAddTargetDebuff(VT VT=15)\nSpellInfo(VT duration=15 durationhaste=spell)\nSpellAddBuff(VT SW=15)\nSpellInfo(MF canStopChannelling=3)\nSpellAddBuff(MF SW=15)\n#SpellInfo(MB cd=5.5)\n#SpellAddBuff(MB SW=15)\nSpellAddBuff(IF IF=1800)\nSpellAddTargetDebuff(DP DP=24)\nSpellInfo(DP duration=24 durationhaste=spell)\nSpellInfo(Focus cd=180)\nSpellInfo(Dispersion cd=120)\nSpellInfo(Shadowfiend cd=300)\nScoreSpells( SWP VT DP MF)\n\n# Add main monitor\nAddIcon help=main\n{\nunless InCombat()\n{\n    #Check shadowform is up\n    unless BuffPresent(SF)\n        Spell(SF)\n        \n    # Refresh inner fire\n    if BuffExpires(IF 400)\n        Spell(IF)\n        \n    if BuffExpires(VE 400) \n        Spell(VE)\n}\n\n\n\n    \n# Check if Shadow Weave is stacked 5 times\n# before suggesting Shadow Word: Pain\nif BuffPresent(SW stacks=5) and TargetDebuffExpires(SWP 0 mine=1) and TargetDeadIn(more 6)\n{\n   Spell(SWP)\n}\n\n#Refresh VT\nif TargetDebuffExpires(VT 1 mine=1 haste=spell) and TargetDeadIn(more 8)\n    Spell(VT)\n  \n\n  \n#Refresh devouring plague  \nunless CheckBoxOn(multidot) and OtherDebuffPresent(DP)\n{\n    if TargetDebuffExpires(DP 0 mine=1) and TargetDeadIn(more 8)\n        Spell(DP)\n}\n\nif CheckBoxOn(multidot) and OtherDebuffExpires(SWP)\n    Texture(INV_Misc_Coin_01) \n\n#cast Mind flay if nothing else can be done\nSpell(MF priority=2)\n\n} # End of main monitor    \n\nAddIcon help=cd\n{\n    Item(Trinket0Slot usable=1)\n    Item(Trinket1Slot usable=1)\n}\n        \n# Add mana monitor\nAddIcon help=mana {\n\n\n\n#Regain mana if needed and if shadowfiend is not already out\nif Mana(less 4000) and PetPresent(no)\n{\n    Spell(Shadowfiend usable=1)\n    unless TargetDebuffExpires(VT 6 mine=1 haste=spell) Spell(Dispersion usable=1)\n}\n}\n\n# Add icons to monitor debuffs (will show up 5 secs before elapsed)\nAddIcon size=small nocd=1 {if TargetDebuffExpires(VT 1.4 mine=1 haste=spell) Spell(VT) } # Vampiric Touch\nAddIcon size=small nocd=1 {if TargetDebuffExpires(SWP 1 mine=1) Spell(SWP) } # Shadow Word: Pain\nAddIcon size=small nocd=1 {if TargetDebuffExpires(DP 1 mine=1) Spell(DP) } \n",
			["check"] = {
				["multidot"] = false,
			},
			["left"] = 454.9629501872135,
			["apparence"] = {
				["targetHostileOnly"] = true,
				["hideEmpty"] = true,
				["smallIconWidth"] = 30,
				["latencyCorrection"] = false,
				["moving"] = false,
				["iconHeight"] = 58,
				["iconWidth"] = 60,
				["avecCible"] = true,
			},
		},
	},
}

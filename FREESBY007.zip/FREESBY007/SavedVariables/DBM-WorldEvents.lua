
DBMWorldEvent_AllSavedVars = nil

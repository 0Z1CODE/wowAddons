
Quartz3DB = {
	["namespaces"] = {
		["Swing"] = {
		},
		["Buff"] = {
			["profiles"] = {
				["Adolifa Hill"] = {
					["focusbuffs"] = false,
					["bufftexture"] = "BantoBar",
					["bufffontsize"] = 10,
					["focusheight"] = 15,
					["focusdebuffs"] = false,
					["focus"] = false,
					["focuswidth"] = 108,
				},
				["Default"] = {
					["bufftexture"] = "BantoBar",
					["focuswidth"] = 108,
					["focus"] = false,
					["bufffontsize"] = 10,
					["focusheight"] = 15,
				},
				["Adolifa DD"] = {
					["focusbuffs"] = false,
					["bufftexture"] = "BantoBar",
					["focuswidth"] = 108,
					["focusheight"] = 15,
					["focus"] = false,
					["focusdebuffs"] = false,
					["bufffontsize"] = 10,
				},
			},
		},
		["Interrupt"] = {
		},
		["Flight"] = {
		},
		["Pet"] = {
			["profiles"] = {
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["x"] = 658.5185392677136,
				},
				["Default"] = {
					["h"] = 10,
					["w"] = 50,
					["hideicon"] = true,
					["x"] = 543.9505883046468,
					["hideblizz"] = false,
					["alpha"] = 0.1000000014901161,
					["scale"] = 0.2000000029802322,
					["y"] = 276.2965273438513,
				},
				["Adolifa DD"] = {
					["y"] = 276.2965273438513,
					["h"] = 10,
					["x"] = 543.9505883046468,
					["w"] = 50,
					["scale"] = 0.2000000029802322,
					["hideblizz"] = false,
					["alpha"] = 0.1000000014901161,
					["hideicon"] = true,
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["x"] = 658.5185392677136,
				},
				["Adolifa Hill"] = {
					["hideicon"] = true,
					["h"] = 10,
					["y"] = 276.2965273438513,
					["alpha"] = 0.1000000014901161,
					["scale"] = 0.2000000029802322,
					["hideblizz"] = false,
					["w"] = 50,
					["x"] = 543.9505883046468,
				},
				["PRIEST"] = {
					["x"] = 658.5185392677136,
				},
			},
		},
		["Player"] = {
			["profiles"] = {
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["y"] = 270,
					["x"] = 633.5185392677136,
				},
				["Default"] = {
					["y"] = 93,
					["icongap"] = 5,
					["nametexty"] = 1,
					["texture"] = "X-Perl 6",
					["x"] = 611,
				},
				["Adolifa DD"] = {
					["y"] = 93,
					["timetextx"] = -2,
					["fontsize"] = 13,
					["nametexty"] = 1,
					["x"] = 611,
					["icongap"] = 5,
					["nametextx"] = -1,
					["texture"] = "Healbot",
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["x"] = 633.5185392677136,
				},
				["Adolifa Hill"] = {
					["y"] = 250,
					["x"] = 611,
					["fontsize"] = 13,
					["nametexty"] = 1,
					["icongap"] = 5,
					["nametextx"] = -1,
					["texture"] = "Healbot",
				},
				["PRIEST"] = {
					["x"] = 633.5185392677136,
				},
			},
		},
		["GCD"] = {
			["profiles"] = {
				["Adolifa Hill"] = {
					["gcdalpha"] = 0.6500000357627869,
				},
				["Adolifa DD"] = {
					["gcdalpha"] = 0.6500000357627869,
				},
			},
		},
		["Focus"] = {
			["profiles"] = {
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["x"] = 658.5185392677136,
				},
				["Default"] = {
					["showhostile"] = false,
					["h"] = 10,
					["showfriendly"] = false,
					["showtarget"] = false,
					["w"] = 50,
					["y"] = -1600,
					["alpha"] = 0.1000000014901161,
					["scale"] = 0.2000000029802322,
					["x"] = -2560,
				},
				["Adolifa DD"] = {
					["showfriendly"] = false,
					["showtarget"] = false,
					["w"] = 50,
					["showhostile"] = false,
					["y"] = -1600,
					["h"] = 10,
					["x"] = -2560,
					["alpha"] = 0.1000000014901161,
					["scale"] = 0.2000000029802322,
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["x"] = 658.5185392677136,
				},
				["Adolifa Hill"] = {
					["showfriendly"] = false,
					["showtarget"] = false,
					["w"] = 50,
					["showhostile"] = false,
					["y"] = -1600,
					["h"] = 10,
					["scale"] = 0.2000000029802322,
					["alpha"] = 0.1000000014901161,
					["x"] = -2560,
				},
				["PRIEST"] = {
					["x"] = 658.5185392677136,
				},
			},
		},
		["Target"] = {
			["profiles"] = {
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["x"] = 658.5185392677136,
				},
				["Default"] = {
					["showhostile"] = false,
					["h"] = 10,
					["showfriendly"] = false,
					["w"] = 50,
					["y"] = 113,
					["x"] = 390.6669877219602,
					["noInterruptChangeBorder"] = false,
					["alpha"] = 0.1000000014901161,
					["scale"] = 0.2000000029802322,
					["hideicon"] = true,
				},
				["Adolifa DD"] = {
					["showfriendly"] = false,
					["noInterruptChangeBorder"] = false,
					["w"] = 50,
					["showhostile"] = false,
					["y"] = 113,
					["h"] = 10,
					["x"] = 390.6669877219602,
					["alpha"] = 0.1000000014901161,
					["scale"] = 0.2000000029802322,
					["hideicon"] = true,
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["x"] = 658.5185392677136,
				},
				["Adolifa Hill"] = {
					["showfriendly"] = false,
					["noInterruptChangeBorder"] = false,
					["w"] = 50,
					["showhostile"] = false,
					["hideicon"] = true,
					["h"] = 10,
					["y"] = 113,
					["scale"] = 0.2000000029802322,
					["alpha"] = 0.1000000014901161,
					["x"] = 390.6669877219602,
				},
				["PRIEST"] = {
					["x"] = 658.5185392677136,
				},
			},
		},
		["Range"] = {
		},
		["Mirror"] = {
			["profiles"] = {
				["Adolifa Hill"] = {
					["mirrorwidth"] = 112,
				},
				["Default"] = {
					["mirrorwidth"] = 112,
				},
				["Adolifa DD"] = {
					["mirrorwidth"] = 112,
				},
			},
		},
		["Latency"] = {
			["profiles"] = {
				["Adolifa Hill"] = {
					["lagcolor"] = {
						nil, -- [1]
						0.2745098039215687, -- [2]
						nil, -- [3]
						1, -- [4]
					},
				},
				["Adolifa DD"] = {
					["lagcolor"] = {
						nil, -- [1]
						0.2745098039215687, -- [2]
						nil, -- [3]
						1, -- [4]
					},
				},
			},
		},
	},
	["profileKeys"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = "Default",
		["Saylee - WoW Circle 3.3.5a x5"] = "Default",
		["Godlite - WoW Circle 3.3.5a x5"] = "Default",
		["Freeby - WoW Circle 3.3.5a x5"] = "Default",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Default",
		["Kadziima - WoW Circle 3.3.5a x5"] = "Default",
		["Brisom - WoW Circle 3.3.5a x5"] = "Default",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa DD",
		["Adamanum - WoW Circle 3.3.5a x5"] = "Adamanum - WoW Circle 3.3.5a x5",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Default",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Default",
	},
	["profiles"] = {
		["Adamanum - WoW Circle 3.3.5a x5"] = {
		},
		["Default"] = {
			["modules"] = {
				["Target"] = false,
				["Latency"] = false,
				["Pet"] = false,
				["Focus"] = false,
			},
			["backgroundcolor"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				1, -- [4]
			},
			["casttimeprecision"] = 3,
		},
		["Adolifa DD"] = {
			["modules"] = {
				["Target"] = false,
				["Pet"] = false,
				["Focus"] = false,
			},
			["casttimeprecision"] = 3,
			["backgroundcolor"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				1, -- [4]
			},
		},
		["Adolifa - WoW Circle 3.3.5a x5"] = {
		},
		["Adolifa Hill"] = {
			["modules"] = {
				["Target"] = false,
				["Pet"] = false,
				["Focus"] = false,
			},
			["casttimeprecision"] = 3,
			["backgroundcolor"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				1, -- [4]
			},
		},
		["PRIEST"] = {
		},
	},
}

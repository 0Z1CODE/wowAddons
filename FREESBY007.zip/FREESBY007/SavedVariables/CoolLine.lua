
CoolLineDB = {
	["bgcolor"] = {
		["a"] = 0.6,
		["b"] = 0,
		["g"] = 0,
		["r"] = 0,
	},
	["border"] = "Blizzard Dialog",
	["statusbar"] = "Blizzard",
	["fontsize"] = 10,
	["block"] = {
		["Камень возвращения"] = true,
	},
	["spellcolor"] = {
		["a"] = 1,
		["b"] = 0,
		["g"] = 0.4,
		["r"] = 0.8,
	},
	["nospellcolor"] = {
		["a"] = 1,
		["b"] = 0,
		["g"] = 0,
		["r"] = 0,
	},
	["inactivealpha"] = 0.5,
	["bordercolor"] = {
		["a"] = 1,
		["b"] = 1,
		["g"] = 1,
		["r"] = 1,
	},
	["w"] = 360,
	["y"] = -240,
	["font"] = "Friz Quadrata TT",
	["dbinit"] = 1,
	["x"] = 0,
	["h"] = 18,
	["fontcolor"] = {
		["a"] = 0.8,
		["b"] = 1,
		["g"] = 1,
		["r"] = 1,
	},
	["activealpha"] = 1,
}

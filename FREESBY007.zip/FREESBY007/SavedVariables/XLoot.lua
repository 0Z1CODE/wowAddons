
XLootDB = {
	["profiles"] = {
		["Default"] = {
			["linkallchannels"] = {
				["ОборонаЛокальный"] = false,
				["ПоискСпутников"] = false,
				["GUILD"] = false,
				["OFFICER"] = false,
				["PARTY"] = false,
				["YELL"] = false,
				["RAID_WARNING"] = false,
				["Общий"] = false,
				["Гильдии"] = false,
				["SAY"] = false,
				["Торговля"] = false,
				["RAID"] = false,
			},
			["pos"] = {
				["y"] = 365.8025516783562,
				["x"] = 814.0001153008857,
			},
		},
	},
}

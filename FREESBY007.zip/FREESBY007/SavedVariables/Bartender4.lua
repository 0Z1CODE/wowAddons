
Bartender4DB = {
	["namespaces"] = {
		["ActionBars"] = {
			["profiles"] = {
				["Drugano - WoW Circle 3.3.5a x5"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 41.99999357159949,
								["x"] = -272.9101575635159,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 22.49992261983857,
								["x"] = 298.0186780596159,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 122.0000077961453,
								["x"] = -272.9814466103215,
								["point"] = "BOTTOM",
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 201.9999826296412,
								["x"] = -272.9814466103215,
								["point"] = "BOTTOM",
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 162.0000170968099,
								["x"] = -272.9814466103215,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 81.99999849548074,
								["x"] = -272.9022793535299,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						[9] = {
						},
						[10] = {
						},
					},
				},
				["Saylee - WoW Circle 3.3.5a x5"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 41.99999357159949,
								["x"] = -216.4875030868291,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 80.57934714942496,
								["x"] = 206.4183453967285,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 77.30614347875356,
								["x"] = -2.999970388325314,
								["point"] = "BOTTOMLEFT",
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 111.9432013885892,
								["x"] = -2.999970388325314,
								["point"] = "BOTTOMLEFT",
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 115.9999980851573,
								["x"] = -215.1420098640386,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 75.99999753805938,
								["x"] = -215.1420098640386,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						[9] = {
						},
						[10] = {
						},
					},
				},
				["Godlite - WoW Circle 3.3.5a x5"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 41.99999357159949,
								["x"] = -189.9394060335736,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["version"] = 3,
							["position"] = {
								["y"] = -189.5000120019606,
								["x"] = -231.4999399218102,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = -151.5000088561475,
								["x"] = -231.4999399218102,
								["point"] = "CENTER",
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = -113.5000407246012,
								["x"] = -231.4999399218102,
								["point"] = "CENTER",
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = -75.50007259305471,
								["x"] = -231.4999399218102,
								["point"] = "CENTER",
							},
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = -37.50006944724169,
								["x"] = -231.4999399218102,
								["point"] = "CENTER",
							},
						}, -- [6]
						{
						}, -- [7]
						[9] = {
						},
						[10] = {
						},
					},
				},
				["Freeby - WoW Circle 3.3.5a x5"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 33.60000236081196,
								["x"] = -185.2000274285765,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -92.00369701416526,
								["x"] = -211.9838980876945,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 128.7901496157277,
								["x"] = -185.2000274285765,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 80.44514621909863,
								["x"] = -2.999970388325314,
								["point"] = "BOTTOMLEFT",
								["scale"] = 0.800000011920929,
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 96.66741669208314,
								["x"] = -185.2000274285765,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 64.43610452608176,
								["x"] = -185.2000274285765,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [6]
						{
						}, -- [7]
						[9] = {
						},
						[10] = {
						},
					},
				},
				["Palamalka - WoW Circle 3.3.5a x5"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 33.60000236081196,
								["x"] = -185.2000274285765,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [1]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 65.10143162429772,
								["x"] = -185.2000274285765,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 95.1514314372447,
								["x"] = -185.2250063959166,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 140.9572682063773,
								["x"] = -1.950009130985104,
								["point"] = "BOTTOMLEFT",
								["scale"] = 0.75,
							},
						}, -- [4]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 156.3483468171314,
								["x"] = -231.4999399218102,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 194.3983400180671,
								["x"] = -208.3247057967171,
								["point"] = "BOTTOM",
								["scale"] = 0.949999988079071,
							},
						}, -- [6]
						{
						}, -- [7]
						[9] = {
						},
						[10] = {
						},
					},
				},
				["Kadziima - WoW Circle 3.3.5a x5"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 41.99999357159949,
								["x"] = -231.4999399218102,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 80.32593139487879,
								["x"] = -231.4999399218102,
								["point"] = "BOTTOM",
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = -184.1309243609093,
								["x"] = -231.4999399218102,
								["point"] = "CENTER",
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 162.3486016279856,
								["x"] = -231.4999399218102,
								["point"] = "BOTTOM",
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 122.3233995624995,
								["x"] = -231.4999399218102,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 200.1969579851369,
								["x"] = -231.4999399218102,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						[9] = {
						},
						[10] = {
						},
					},
				},
				["Brisom - WoW Circle 3.3.5a x5"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 33.60000236081196,
								["x"] = -225.141334155738,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -67.11478599820509,
								["x"] = 298.0186780596159,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 61.44925663412642,
								["x"] = -2.24999112675568,
								["point"] = "BOTTOMLEFT",
								["scale"] = 0.75,
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 120.207014739023,
								["x"] = -2.24999112675568,
								["point"] = "BOTTOMLEFT",
								["scale"] = 0.75,
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 90.81152907644196,
								["x"] = -2.24999112675568,
								["point"] = "BOTTOMLEFT",
								["scale"] = 0.75,
							},
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 65.60000677675417,
								["x"] = -225.141334155738,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [6]
						{
						}, -- [7]
						[9] = {
						},
						[10] = {
						},
					},
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 35.69999925748338,
								["x"] = -196.7749314263419,
								["point"] = "BOTTOM",
								["scale"] = 0.8500000238418579,
							},
						}, -- [1]
						{
							["rows"] = 4,
							["version"] = 3,
							["position"] = {
								["y"] = -75.9647442614272,
								["x"] = -76.69982021704004,
								["point"] = "RIGHT",
								["scale"] = 0.6500000357627869,
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 91.60681467899269,
								["x"] = -2.24999112675568,
								["point"] = "BOTTOMLEFT",
								["scale"] = 0.75,
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 64.55097355732161,
								["x"] = -2.24999112675568,
								["point"] = "BOTTOMLEFT",
								["scale"] = 0.75,
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 67.36005013249267,
								["x"] = -196.7749314263419,
								["point"] = "BOTTOM",
								["scale"] = 0.8500000238418579,
							},
						}, -- [5]
						{
							["buttons"] = 6,
							["rows"] = 2,
							["version"] = 3,
							["position"] = {
								["y"] = 56.00000593975931,
								["x"] = -312.4907672342533,
								["point"] = "BOTTOMRIGHT",
								["scale"] = 0.699999988079071,
							},
						}, -- [6]
						{
						}, -- [7]
						[9] = {
						},
						[10] = {
						},
					},
				},
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 35.69999925748338,
								["x"] = -196.7749314263419,
								["point"] = "BOTTOM",
								["scale"] = 0.8500000238418579,
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 62.73452750674965,
								["x"] = 68.51856046775778,
								["point"] = "BOTTOMLEFT",
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 108.3046676137387,
								["x"] = -2.24999112675568,
								["point"] = "BOTTOMLEFT",
								["scale"] = 0.75,
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 99.46192837927509,
								["x"] = -150.4249308143395,
								["point"] = "BOTTOM",
								["scale"] = 0.75,
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 69.36194755157088,
								["x"] = -196.7749314263419,
								["point"] = "BOTTOM",
								["scale"] = 0.8500000238418579,
							},
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 78.75652193715609,
								["x"] = -2.24999112675568,
								["point"] = "BOTTOMLEFT",
								["scale"] = 0.75,
							},
						}, -- [6]
						{
						}, -- [7]
						[9] = {
						},
						[10] = {
						},
					},
				},
				["Pinichet - WoW Circle 3.3.5a x5"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 33.60000236081196,
								["x"] = -227.7329221399011,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [1]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 65.60000677675417,
								["x"] = -227.7329221399011,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 97.60000068841625,
								["x"] = -227.7329221399011,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 129.6000016029317,
								["x"] = -227.7329221399011,
								["point"] = "BOTTOM",
								["scale"] = 0.800000011920929,
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 71.75265757941588,
								["x"] = -2.999970388325314,
								["point"] = "BOTTOMLEFT",
								["scale"] = 0.8,
							},
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 103.1616948900783,
								["x"] = -2.400007640423929,
								["point"] = "BOTTOMLEFT",
								["scale"] = 0.800000011920929,
							},
						}, -- [6]
						{
						}, -- [7]
						[9] = {
						},
						[10] = {
						},
					},
				},
				["Drmartin - WoW Circle 3.3.5a x5"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 35.69999925748338,
								["x"] = -196.7749314263419,
								["point"] = "BOTTOM",
								["scale"] = 0.8500000238418579,
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 147.7234926101775,
								["x"] = -231.4999399218102,
								["point"] = "BOTTOM",
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 147.8499966375471,
								["x"] = -196.8499503041969,
								["point"] = "BOTTOM",
								["scale"] = 0.699999988079071,
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 119.8499967314157,
								["x"] = -196.8499503041969,
								["point"] = "BOTTOM",
								["scale"] = 0.699999988079071,
							},
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 63.84999691915299,
								["x"] = -196.8499503041969,
								["point"] = "BOTTOM",
								["scale"] = 0.699999988079071,
							},
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 91.8499906977878,
								["x"] = -196.8499503041969,
								["point"] = "BOTTOM",
								["scale"] = 0.699999988079071,
							},
						}, -- [6]
						{
						}, -- [7]
						[9] = {
						},
						[10] = {
						},
					},
				},
			},
		},
		["MicroMenu"] = {
			["profiles"] = {
				["Drugano - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 32.40000390215965,
						["x"] = -4.399997412140179,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.800000011920929,
					},
				},
				["Saylee - WoW Circle 3.3.5a x5"] = {
					["position"] = {
						["y"] = 32.40000390215965,
						["x"] = -4.399997412140179,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.800000011920929,
					},
					["version"] = 3,
				},
				["Godlite - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["scale"] = 0.800000011920929,
						["x"] = 30.49186990230349,
						["point"] = "BOTTOMLEFT",
						["y"] = 32.40000390215965,
					},
				},
				["Freeby - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 32.40000390215965,
						["x"] = -4.399997412140179,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.800000011920929,
					},
				},
				["Palamalka - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 32.40000390215965,
						["x"] = -4.399997412140179,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.800000011920929,
					},
				},
				["Kadziima - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 32.40000390215965,
						["x"] = -4.399997412140179,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.800000011920929,
					},
				},
				["Brisom - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 32.40000390215965,
						["x"] = -4.399997412140179,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.800000011920929,
					},
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 32.40000390215965,
						["x"] = 38.29748492555725,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.800000011920929,
					},
				},
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 32.40000390215965,
						["x"] = -4.399997412140179,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.75,
					},
				},
				["Pinichet - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 32.40000390215965,
						["x"] = -4.399997412140179,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.800000011920929,
					},
				},
				["Drmartin - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 32.40000390215965,
						["x"] = -4.399997412140179,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.800000011920929,
					},
				},
			},
		},
		["XPBar"] = {
			["profiles"] = {
				["Saylee - WoW Circle 3.3.5a x5"] = {
					["enabled"] = true,
					["position"] = {
						["y"] = 3.999889759769985,
						["x"] = 269.8567909657174,
						["point"] = "TOPLEFT",
					},
					["version"] = 3,
				},
			},
		},
		["MultiCast"] = {
			["profiles"] = {
				["Brisom - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 28.00000080020106,
						["x"] = 342.6845763365292,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.800000011920929,
					},
				},
			},
		},
		["BagBar"] = {
			["profiles"] = {
				["Drugano - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 35.99999699096146,
						["x"] = 184.6261661477556,
						["point"] = "BOTTOM",
					},
				},
				["Saylee - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 35.99999699096146,
						["x"] = 362.0838614936827,
						["point"] = "BOTTOM",
					},
				},
				["Godlite - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 35.99999699096146,
						["x"] = -313.6788087982372,
						["point"] = "BOTTOMRIGHT",
					},
				},
				["Freeby - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 35.99999699096146,
						["x"] = 225.6333345665832,
						["point"] = "BOTTOM",
					},
				},
				["Palamalka - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 28.79999802192258,
						["x"] = -348.8151317334221,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 0.800000011920929,
					},
				},
				["Kadziima - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 35.99999699096146,
						["x"] = 377.4952508823492,
						["point"] = "BOTTOM",
					},
				},
				["Brisom - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 35.99999699096146,
						["x"] = -163.9998219196284,
						["point"] = "BOTTOMRIGHT",
					},
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 35.99999699096146,
						["x"] = 226.6603730346105,
						["point"] = "BOTTOM",
					},
				},
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 26.99999938451484,
						["x"] = -360.5792984577106,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 0.75,
					},
				},
				["Pinichet - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 35.99999699096146,
						["x"] = -163.9998219196284,
						["point"] = "BOTTOMRIGHT",
					},
				},
				["Drmartin - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 35.99999699096146,
						["x"] = 246.018710611942,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["Vehicle"] = {
			["profiles"] = {
				["Drugano - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 80.00000109419584,
						["x"] = 184.0383466400084,
						["point"] = "BOTTOM",
					},
				},
				["Saylee - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 46.00000150451927,
						["x"] = -129.9998485906519,
						["point"] = "BOTTOMRIGHT",
					},
				},
				["Godlite - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 46.00000150451927,
						["x"] = 312.2754369927504,
						["point"] = "BOTTOM",
					},
				},
				["Freeby - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 46.00000150451927,
						["x"] = -129.9998485906519,
						["point"] = "BOTTOMRIGHT",
					},
				},
				["Palamalka - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 59.70000281983913,
						["x"] = -304.1399208142495,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 0.699999988079071,
					},
				},
				["Kadziima - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 46.00000150451927,
						["x"] = 243.0607053692395,
						["point"] = "BOTTOM",
					},
				},
				["Brisom - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 27.60000199943706,
						["x"] = 200.8646145009569,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.6000000238418579,
					},
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 46.00000150451927,
						["x"] = -129.9998485906519,
						["point"] = "BOTTOMRIGHT",
					},
				},
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 34.50000112838945,
						["x"] = 191.7534601720582,
						["point"] = "BOTTOM",
						["scale"] = 0.75,
					},
				},
				["Pinichet - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 27.60000199943706,
						["x"] = -295.8959946657656,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 0.6000000238418579,
					},
				},
				["Drmartin - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 46.00000150451927,
						["x"] = -294.3554154589765,
						["point"] = "BOTTOMRIGHT",
					},
				},
			},
		},
		["StanceBar"] = {
			["profiles"] = {
				["Drugano - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 53.99999876902969,
						["x"] = 336.9659046527327,
						["point"] = "BOTTOMLEFT",
					},
				},
				["Saylee - WoW Circle 3.3.5a x5"] = {
					["position"] = {
						["y"] = 53.99999876902969,
						["x"] = -276.0344805725872,
						["point"] = "BOTTOM",
					},
					["version"] = 3,
				},
				["Godlite - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -14.99999801677006,
						["x"] = -82.49992344048542,
						["point"] = "CENTER",
					},
				},
				["Freeby - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 53.99999876902969,
						["x"] = -293.3557231331669,
						["point"] = "BOTTOM",
					},
				},
				["Palamalka - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 37.80000401105278,
						["x"] = 335.1599108701025,
						["point"] = "BOTTOMLEFT",
						["scale"] = 1.050000071525574,
					},
				},
				["Kadziima - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -14.99999801677006,
						["x"] = -82.49992344048542,
						["point"] = "CENTER",
					},
				},
				["Brisom - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -14.99999801677006,
						["x"] = -82.49992344048542,
						["point"] = "CENTER",
					},
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 53.99999876902969,
						["x"] = -248.8278702073112,
						["point"] = "BOTTOM",
					},
				},
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 43.20000073183748,
						["x"] = 329.8590475575606,
						["point"] = "BOTTOMLEFT",
						["scale"] = 1.200000047683716,
					},
				},
				["Pinichet - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -14.99999801677006,
						["x"] = -82.49992344048542,
						["point"] = "CENTER",
					},
				},
				["Drmartin - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 53.99999876902969,
						["x"] = 341.1767816294915,
						["point"] = "BOTTOMLEFT",
					},
				},
			},
		},
		["PetBar"] = {
			["profiles"] = {
				["Drugano - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 66.21845141062701,
						["x"] = -2.999996649025266,
						["point"] = "BOTTOMLEFT",
					},
				},
				["Saylee - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 120.1629492845019,
						["x"] = -323.9997540794868,
						["point"] = "BOTTOMRIGHT",
					},
				},
				["Godlite - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 89.50000188064905,
						["x"] = -163.4998882210571,
						["point"] = "CENTER",
					},
				},
				["Freeby - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 111.7087020915758,
						["x"] = -2.999996649025266,
						["point"] = "BOTTOMLEFT",
					},
				},
				["Palamalka - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 89.50000188064905,
						["x"] = -163.4998882210571,
						["point"] = "CENTER",
					},
				},
				["Kadziima - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 110.9185876585242,
						["x"] = 204.5185763335973,
						["point"] = "BOTTOMLEFT",
					},
				},
				["Brisom - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -206.1641418211837,
						["x"] = -323.9997540794868,
						["point"] = "TOPRIGHT",
					},
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 104.1552581820032,
						["x"] = -323.9997540794868,
						["point"] = "RIGHT",
					},
				},
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -57.50995249753964,
						["x"] = -2.999996649025266,
						["point"] = "LEFT",
					},
				},
				["Pinichet - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -86.05183191975772,
						["x"] = -28.02835143463777,
						["point"] = "LEFT",
					},
				},
				["Drmartin - WoW Circle 3.3.5a x5"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 89.50000188064905,
						["x"] = -163.4998882210571,
						["point"] = "CENTER",
					},
				},
			},
		},
		["RepBar"] = {
		},
	},
	["profileKeys"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = "Drugano - WoW Circle 3.3.5a x5",
		["Saylee - WoW Circle 3.3.5a x5"] = "Saylee - WoW Circle 3.3.5a x5",
		["Godlite - WoW Circle 3.3.5a x5"] = "Godlite - WoW Circle 3.3.5a x5",
		["Freeby - WoW Circle 3.3.5a x5"] = "Freeby - WoW Circle 3.3.5a x5",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Palamalka - WoW Circle 3.3.5a x5",
		["Kadziima - WoW Circle 3.3.5a x5"] = "Kadziima - WoW Circle 3.3.5a x5",
		["Brisom - WoW Circle 3.3.5a x5"] = "Brisom - WoW Circle 3.3.5a x5",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa - WoW Circle 3.3.5a x5",
		["Adamanum - WoW Circle 3.3.5a x5"] = "Adamanum - WoW Circle 3.3.5a x5",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Pinichet - WoW Circle 3.3.5a x5",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Drmartin - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = {
		},
		["Saylee - WoW Circle 3.3.5a x5"] = {
		},
		["Godlite - WoW Circle 3.3.5a x5"] = {
		},
		["Freeby - WoW Circle 3.3.5a x5"] = {
		},
		["Palamalka - WoW Circle 3.3.5a x5"] = {
			["snapping"] = 1,
		},
		["Kadziima - WoW Circle 3.3.5a x5"] = {
		},
		["Brisom - WoW Circle 3.3.5a x5"] = {
		},
		["Adolifa - WoW Circle 3.3.5a x5"] = {
		},
		["Adamanum - WoW Circle 3.3.5a x5"] = {
		},
		["Pinichet - WoW Circle 3.3.5a x5"] = {
			["snapping"] = 1,
		},
		["Drmartin - WoW Circle 3.3.5a x5"] = {
		},
	},
}

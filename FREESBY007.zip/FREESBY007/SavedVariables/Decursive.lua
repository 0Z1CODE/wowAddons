
DecursiveDB = {
	["class"] = {
		["DEATHKNIGHT"] = {
			["CureOrder"] = {
				-12, -- [1]
				-11, -- [2]
				nil, -- [3]
				-13, -- [4]
				[32] = -16,
				[16] = -15,
				[8] = -14,
			},
		},
		["WARRIOR"] = {
			["CureOrder"] = {
				-12, -- [1]
				-11, -- [2]
				nil, -- [3]
				-13, -- [4]
				[32] = -16,
				[16] = -15,
				[8] = -14,
			},
		},
		["ROGUE"] = {
			["CureOrder"] = {
				-12, -- [1]
				-11, -- [2]
				nil, -- [3]
				-13, -- [4]
				[32] = -16,
				[16] = -15,
				[8] = -14,
			},
		},
		["MAGE"] = {
			["CureOrder"] = {
				-14, -- [1]
				-13, -- [2]
				nil, -- [3]
				1, -- [4]
				[32] = 2,
				[16] = -16,
				[8] = -15,
			},
		},
		["PRIEST"] = {
			["CureOrder"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				-15, -- [4]
				[32] = -16,
				[16] = 3,
				[8] = -14,
			},
		},
		["WARLOCK"] = {
			["CureOrder"] = {
				-12, -- [1]
				-11, -- [2]
				nil, -- [3]
				-13, -- [4]
				[32] = -16,
				[16] = -15,
				[8] = -14,
			},
		},
		["SHAMAN"] = {
			["CureOrder"] = {
				-15, -- [1]
				nil, -- [2]
				nil, -- [3]
				-16, -- [4]
				[32] = 4,
				[16] = 3,
				[8] = 2,
			},
		},
		["DRUID"] = {
			["CureOrder"] = {
				-15, -- [1]
				-14, -- [2]
				nil, -- [3]
				1, -- [4]
				[32] = 3,
				[16] = -16,
				[8] = 2,
			},
		},
		["HUNTER"] = {
			["CureOrder"] = {
				-12, -- [1]
				nil, -- [2]
				nil, -- [3]
				-13, -- [4]
				[32] = -16,
				[16] = -15,
				[8] = -14,
			},
		},
		["PALADIN"] = {
			["CureOrder"] = {
				1, -- [1]
				-14, -- [2]
				nil, -- [3]
				-15, -- [4]
				[32] = -16,
				[16] = 3,
				[8] = 2,
			},
		},
	},
	["profileKeys"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = "Default",
		["Saylee - WoW Circle 3.3.5a x5"] = "Default",
		["Godlite - WoW Circle 3.3.5a x5"] = "Default",
		["Freeby - WoW Circle 3.3.5a x5"] = "Default",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Default",
		["Brisom - WoW Circle 3.3.5a x5"] = "Default",
		["Adamanum - WoW Circle 3.3.5a x5"] = "Default",
		["Kadziima - WoW Circle 3.3.5a x5"] = "Default",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Default",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Default",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["MainBarX"] = 682.666667256451,
			["MainBarY"] = -96.00001977846296,
			["DebuffsFrame_x"] = 887.4790708868595,
			["DebuffsFrame_y"] = -660.8009244879445,
			["Hidden"] = true,
		},
	},
}


EPGPLootMaster = {
	["profileKeys"] = {
		["Adamanum - WoW Circle 3.3.5a x5"] = "Adamanum - WoW Circle 3.3.5a x5",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa - WoW Circle 3.3.5a x5",
		["Godlite - WoW Circle 3.3.5a x5"] = "Godlite - WoW Circle 3.3.5a x5",
		["Freeby - WoW Circle 3.3.5a x5"] = "Freeby - WoW Circle 3.3.5a x5",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Palamalka - WoW Circle 3.3.5a x5",
		["Brisom - WoW Circle 3.3.5a x5"] = "Brisom - WoW Circle 3.3.5a x5",
		["Drugano - WoW Circle 3.3.5a x5"] = "Drugano - WoW Circle 3.3.5a x5",
		["Kadziima - WoW Circle 3.3.5a x5"] = "Kadziima - WoW Circle 3.3.5a x5",
		["Saylee - WoW Circle 3.3.5a x5"] = "Saylee - WoW Circle 3.3.5a x5",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Pinichet - WoW Circle 3.3.5a x5",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Drmartin - WoW Circle 3.3.5a x5",
	},
	["profiles"] = {
		["Adamanum - WoW Circle 3.3.5a x5"] = {
		},
		["Saylee - WoW Circle 3.3.5a x5"] = {
		},
		["Godlite - WoW Circle 3.3.5a x5"] = {
		},
		["Freeby - WoW Circle 3.3.5a x5"] = {
		},
		["Palamalka - WoW Circle 3.3.5a x5"] = {
		},
		["Kadziima - WoW Circle 3.3.5a x5"] = {
		},
		["Drugano - WoW Circle 3.3.5a x5"] = {
		},
		["Adolifa - WoW Circle 3.3.5a x5"] = {
			["use_epgplootmaster"] = "disabled",
		},
		["Brisom - WoW Circle 3.3.5a x5"] = {
		},
		["Pinichet - WoW Circle 3.3.5a x5"] = {
		},
		["Drmartin - WoW Circle 3.3.5a x5"] = {
		},
	},
}

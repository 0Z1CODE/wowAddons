
SexyMapDB = {
	["namespaces"] = {
		["Ping"] = {
		},
		["Coordinates"] = {
		},
		["Buttons"] = {
			["profiles"] = {
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["dragPositions"] = {
						["MiniMapTrackingButton"] = 104.2513362951909,
						["MiniMapMailFrame"] = 5.349346753777378,
						["WIM3MinimapButton"] = -12.73877315916672,
						["MiniMapWorldMapButton"] = 157.5205494017509,
						["LibDBIcon10_Omen"] = 78.83786316865064,
						["LibDBIcon10_Skada"] = 121.4926863821986,
						["AltoholicMinimapButton"] = 182.9382826775729,
						["FuBarPluginAtlasLootFuFrameMinimapButton"] = 199.9029131169777,
						["LibDBIcon10_Bartender4"] = 217.6434661277083,
						["LibDBIcon10_DBM"] = -29.85885388059785,
						["MinimapZoomIn"] = -58.26748538980094,
						["DBMMinimapButton"] = 14.53539571464366,
						["MageNug_MinimapFrame"] = 111.869032722343,
						["PS_MinimapButton"] = 62.84163530575747,
						["GameTimeFrame"] = 53.71277394224164,
						["XPerl_MinimapButton_Frame"] = 29.72104155495221,
					},
				},
				["Saylee - WoW Circle 3.3.5a x5"] = {
					["dragPositions"] = {
						["PS_MinimapButton"] = -50.70415578215611,
						["MiniMapMailFrame"] = -12.44539909734707,
						["WIM3MinimapButton"] = 236.6863352986003,
						["MiniMapTrackingButton"] = 108.0207033935152,
						["LibDBIcon10_Omen"] = 48.99554506515474,
						["GameTimeFrame"] = 61.77072528833092,
						["AltoholicMinimapButton"] = 171.9350899517881,
						["FuBarPluginAtlasLootFuFrameMinimapButton"] = 209.3297845507154,
						["LibDBIcon10_Bartender4"] = -3.386234757246302,
						["LibDBIcon10_DBM"] = 249.4867296300466,
						["MiniMapWorldMapButton"] = 78.8106159359215,
						["DBMMinimapButton"] = 106.5418769089163,
						["MageNug_MinimapFrame"] = 51.1428624492121,
						["MinimapZoomIn"] = -28.75120667540261,
						["LibDBIcon10_Skada"] = 228.636362353891,
						["XPerl_MinimapButton_Frame"] = 132.0531302748174,
					},
				},
				["Godlite - WoW Circle 3.3.5a x5"] = {
					["dragPositions"] = {
						["PS_MinimapButton"] = -47.6089783875592,
						["LibDBIcon10_DBM"] = -54.28591748550917,
						["LibDBIcon10_Omen"] = 232.5432059692753,
						["LibDBIcon10_Bartender4"] = 150.4162089240174,
						["AltoholicMinimapButton"] = 17.86825377324947,
						["XPerl_MinimapButton_Frame"] = -18.54765030647511,
					},
				},
				["Freeby - WoW Circle 3.3.5a x5"] = {
					["dragPositions"] = {
						["MiniMapTrackingButton"] = 140.4761026963543,
						["LibDBIcon10_Omen"] = -29.30687935516369,
						["LibDBIcon10_Skada"] = 224.8707904777466,
						["AltoholicMinimapButton"] = -1.928319302421981,
						["LibDBIcon10_Bartender4"] = 160.4334335321326,
						["LibDBIcon10_DBM"] = 5.984237860118736,
						["DBMMinimapButton"] = 227.2953692739205,
						["MageNug_MinimapFrame"] = 121.0845934423005,
						["WIM3MinimapButton"] = 198.0864877457837,
						["PS_MinimapButton"] = -16.00190003437911,
						["XPerl_MinimapButton_Frame"] = 74.14263034760349,
					},
				},
				["Palamalka - WoW Circle 3.3.5a x5"] = {
					["dragPositions"] = {
						["MiniMapTrackingButton"] = 81.07091425850159,
						["MiniMapMailFrame"] = 10.68603772479323,
						["LibDBIcon10_Omen"] = -4.742048057354207,
						["LibDBIcon10_Skada"] = 110.5430344654463,
						["AltoholicMinimapButton"] = 206.4357906661997,
						["FuBarPluginAtlasLootFuFrameMinimapButton"] = 157.3907762644079,
						["LibDBIcon10_Bartender4"] = 98.57999035015421,
						["LibDBIcon10_DBM"] = 172.7818662678861,
						["DBMMinimapButton"] = 170.561186152881,
						["WIM3MinimapButton"] = 189.218406699174,
						["PS_MinimapButton"] = 62.92972517585734,
						["GameTimeFrame"] = 38.45262564159531,
						["XPerl_MinimapButton_Frame"] = -20.40092954975731,
					},
				},
				["Brisom - WoW Circle 3.3.5a x5"] = {
					["dragPositions"] = {
						["LibDBIcon10_Bartender4"] = 104.7802223046973,
						["LibDBIcon10_DBM"] = -28.13688170641972,
						["PS_MinimapButton"] = 72.20994507433804,
						["LibDBIcon10_Omen"] = 118.6203984875491,
						["MiniMapTrackingButton"] = 158.0491503423572,
						["AltoholicMinimapButton"] = -9.975464587850897,
						["XPerl_MinimapButton_Frame"] = 149.4195636266922,
					},
				},
				["Drugano - WoW Circle 3.3.5a x5"] = {
					["dragPositions"] = {
						["LibDBIcon10_Bartender4"] = 89.92752418299452,
						["LibDBIcon10_DBM"] = 16.00560469930619,
						["MiniMapTrackingButton"] = 72.09642501674595,
						["DBMMinimapButton"] = 264.2185511122428,
						["LibDBIcon10_Omen"] = 167.7197334922111,
						["LibDBIcon10_Skada"] = -72.04306515659194,
						["PS_MinimapButton"] = 113.6366714740573,
						["XPerl_MinimapButton_Frame"] = -24.20561265154521,
					},
				},
				["Kadziima - WoW Circle 3.3.5a x5"] = {
					["dragPositions"] = {
						["LibDBIcon10_Bartender4"] = 141.2194221201259,
						["LibDBIcon10_DBM"] = -30.07938646793348,
						["LibDBIcon10_Omen"] = 158.3911253900836,
						["MiniMapTrackingButton"] = 109.3628089560317,
						["PS_MinimapButton"] = 135.1671526631229,
					},
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["dragPositions"] = {
						["MiniMapTrackingButton"] = 140.6794494927257,
						["WIM3MinimapButton"] = -22.67733016598425,
						["FuBarPluginAtlasLootFuFrameMinimapButton"] = 183.5462973563337,
						["LibDBIcon10_Omen"] = -68.86095332644912,
						["LibDBIcon10_Skada"] = 140.1803144815863,
						["AltoholicMinimapButton"] = 120.5771277533151,
						["MiniMapWorldMapButton"] = 70.23351473981606,
						["LibDBIcon10_Bartender4"] = 199.1743084326487,
						["LibDBIcon10_DBM"] = 57.03644864788977,
						["MinimapZoomIn"] = -42.01380724895346,
						["DBMMinimapButton"] = -38.61899173858507,
						["MageNug_MinimapFrame"] = 244.4829972772176,
						["PS_MinimapButton"] = 26.5073325195811,
						["GameTimeFrame"] = 36.64701086407762,
						["XPerl_MinimapButton_Frame"] = 1.549520060308901,
					},
				},
				["Pinichet - WoW Circle 3.3.5a x5"] = {
					["dragPositions"] = {
						["PS_MinimapButton"] = 141.0961142732458,
						["MiniMapMailFrame"] = 0.2945575396309157,
						["LibDBIcon10_Omen"] = 68.23657264631528,
						["LibDBIcon10_Skada"] = 221.5327428033679,
						["AltoholicMinimapButton"] = 26.49884385725345,
						["FuBarPluginAtlasLootFuFrameMinimapButton"] = 180.3432490971527,
						["LibDBIcon10_Bartender4"] = 167.2376914167677,
						["LibDBIcon10_DBM"] = -17.22834467209441,
						["XPerl_MinimapButton_Frame"] = 67.47866851322975,
						["DBMMinimapButton"] = 68.10026017017943,
						["MageNug_MinimapFrame"] = 111.9717121393225,
						["MiniMapTrackingButton"] = 152.1782776563187,
						["GameTimeFrame"] = 88.41923085225611,
						["WIM3MinimapButton"] = 205.4830994794408,
					},
				},
				["Drmartin - WoW Circle 3.3.5a x5"] = {
					["dragPositions"] = {
						["LibDBIcon10_Bartender4"] = 162.8318814786053,
						["LibDBIcon10_DBM"] = -18.18797711161611,
						["LibDBIcon10_Omen"] = 72.03447980356769,
						["DBMMinimapButton"] = 240.2561279880077,
						["MageNug_MinimapFrame"] = 110.9173004238951,
						["PS_MinimapButton"] = 217.8322468459933,
						["MiniMapTrackingButton"] = 148.70034253176,
						["XPerl_MinimapButton_Frame"] = -35.64655178953952,
					},
				},
			},
		},
		["AutoZoom"] = {
		},
		["Shapes"] = {
			["profiles"] = {
				["Drugano - WoW Circle 3.3.5a x5"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Saylee - WoW Circle 3.3.5a x5"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Godlite - WoW Circle 3.3.5a x5"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Freeby - WoW Circle 3.3.5a x5"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Palamalka - WoW Circle 3.3.5a x5"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Kadziima - WoW Circle 3.3.5a x5"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Brisom - WoW Circle 3.3.5a x5"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Pinichet - WoW Circle 3.3.5a x5"] = {
					["shape"] = "Textures\\MinimapMask",
				},
				["Drmartin - WoW Circle 3.3.5a x5"] = {
					["shape"] = "Textures\\MinimapMask",
				},
			},
		},
		["Fader"] = {
		},
		["Movers"] = {
		},
		["Borders"] = {
			["profiles"] = {
				["Drugano - WoW Circle 3.3.5a x5"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["b"] = 1,
							["name"] = "Rune 1",
							["r"] = 0.3098039215686275,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["b"] = 1,
							["rotSpeed"] = 4,
							["r"] = 0.196078431372549,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Saylee - WoW Circle 3.3.5a x5"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Godlite - WoW Circle 3.3.5a x5"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["b"] = 1,
							["name"] = "Rune 1",
							["r"] = 0.3098039215686275,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["b"] = 1,
							["rotSpeed"] = 4,
							["r"] = 0.196078431372549,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Freeby - WoW Circle 3.3.5a x5"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Palamalka - WoW Circle 3.3.5a x5"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Kadziima - WoW Circle 3.3.5a x5"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Brisom - WoW Circle 3.3.5a x5"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["b"] = 1,
							["name"] = "Rune 1",
							["r"] = 0.3098039215686275,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["b"] = 1,
							["rotSpeed"] = 4,
							["r"] = 0.196078431372549,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Pinichet - WoW Circle 3.3.5a x5"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["b"] = 1,
							["name"] = "Rune 1",
							["r"] = 0.3098039215686275,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["b"] = 1,
							["rotSpeed"] = 4,
							["r"] = 0.196078431372549,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
				["Drmartin - WoW Circle 3.3.5a x5"] = {
					["applyPreset"] = false,
					["borders"] = {
						{
							["a"] = 1,
							["r"] = 0.3098039215686275,
							["name"] = "Rune 1",
							["b"] = 1,
							["scale"] = 1.4,
							["rotSpeed"] = -16,
							["g"] = 0.4784313725490196,
							["texture"] = "SPELLS\\AURARUNE256.BLP",
						}, -- [1]
						{
							["a"] = 0.3799999952316284,
							["r"] = 0.196078431372549,
							["rotSpeed"] = 4,
							["b"] = 1,
							["scale"] = 2.1,
							["name"] = "Rune 2",
							["g"] = 0.2901960784313725,
							["texture"] = "SPELLS\\AuraRune_A.blp",
						}, -- [2]
						{
							["a"] = 0.3,
							["name"] = "Fade",
							["b"] = 1,
							["scale"] = 1.6,
							["r"] = 0,
							["g"] = 0.2235294117647059,
							["texture"] = "SPELLS\\T_VFX_HERO_CIRCLE.BLP",
						}, -- [3]
					},
				},
			},
		},
		["HudMap"] = {
			["profiles"] = {
				["Drugano - WoW Circle 3.3.5a x5"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["Saylee - WoW Circle 3.3.5a x5"] = {
					["setNewScale"] = true,
					["scale"] = 1.4,
				},
				["Godlite - WoW Circle 3.3.5a x5"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["Freeby - WoW Circle 3.3.5a x5"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["Palamalka - WoW Circle 3.3.5a x5"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["Kadziima - WoW Circle 3.3.5a x5"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["Brisom - WoW Circle 3.3.5a x5"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["Adolifa - WoW Circle 3.3.5a x5"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["Adamanum - WoW Circle 3.3.5a x5"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["Pinichet - WoW Circle 3.3.5a x5"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
				["Drmartin - WoW Circle 3.3.5a x5"] = {
					["scale"] = 1.4,
					["setNewScale"] = true,
				},
			},
		},
		["ZoneText"] = {
		},
	},
	["profileKeys"] = {
		["Drugano - WoW Circle 3.3.5a x5"] = "Drugano - WoW Circle 3.3.5a x5",
		["Saylee - WoW Circle 3.3.5a x5"] = "Saylee - WoW Circle 3.3.5a x5",
		["Godlite - WoW Circle 3.3.5a x5"] = "Godlite - WoW Circle 3.3.5a x5",
		["Freeby - WoW Circle 3.3.5a x5"] = "Freeby - WoW Circle 3.3.5a x5",
		["Palamalka - WoW Circle 3.3.5a x5"] = "Palamalka - WoW Circle 3.3.5a x5",
		["Kadziima - WoW Circle 3.3.5a x5"] = "Kadziima - WoW Circle 3.3.5a x5",
		["Brisom - WoW Circle 3.3.5a x5"] = "Brisom - WoW Circle 3.3.5a x5",
		["Adolifa - WoW Circle 3.3.5a x5"] = "Adolifa - WoW Circle 3.3.5a x5",
		["Adamanum - WoW Circle 3.3.5a x5"] = "Adamanum - WoW Circle 3.3.5a x5",
		["Pinichet - WoW Circle 3.3.5a x5"] = "Pinichet - WoW Circle 3.3.5a x5",
		["Drmartin - WoW Circle 3.3.5a x5"] = "Drmartin - WoW Circle 3.3.5a x5",
	},
}

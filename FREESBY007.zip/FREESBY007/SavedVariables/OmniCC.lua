
OmniCCGlobalSettings = {
	["scaleText"] = false,
	["version"] = "3.0.4",
	["minDuration"] = 1,
	["minFontSize"] = 52,
}
